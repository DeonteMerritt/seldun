# Seldun Programming Language

Seldun is an original, general-purpose programming language created by Deonte
Lamar Merritt. Its source files use the `.sld` extension. The native Seldun
tool is written in standard C++17 and does not use Java or Python.

Seldun 1.0 includes a lexer, parser, bytecode compiler, portable `.slbc`
bytecode format, and stack-based virtual machine in one native executable.

## First program

```seldun
let name = "Deonte";
say "Hello, " + name + "!";

fn square(number) {
    return number * number;
}

say square(8);
```

## Language features

- Values: numbers, strings, booleans, and `nil`
- Variables declared with `let`
- Output with `say`
- Arithmetic: `+ - * / %`
- Comparisons: `== != < <= > >=`
- Logic: `and`, `or`, and `!`
- Control flow: `if`/`else` and `while`
- Functions declared with `fn`, parameters, calls, and `return`
- Comments beginning with `#` or `//`
- Built-in `clock()` function

Statements end with a semicolon. Blocks use braces.

## Build on Windows

1. Install **Visual Studio Community 2022** and select **Desktop development
   with C++** in the installer.
2. Install CMake and enable its **Add to PATH** option.
3. Open **Developer Command Prompt for VS 2022**.
4. Change to this Seldun folder.
5. Run `build-windows.bat`.

The executable will be `build\Release\seldun.exe`.

## Build on Linux or macOS

Install a C++17 compiler and CMake, then run:

```sh
chmod +x build-linux-macos.sh
./build-linux-macos.sh
```

## Commands

Run source code immediately:

```sh
seldun run examples/hello.sld
```

Compile source code to Seldun bytecode:

```sh
seldun compile examples/hello.sld -o hello.slbc
```

Execute the compiled bytecode:

```sh
seldun exec hello.slbc
```

Show the version:

```sh
seldun --version
```

On Windows, use `build\Release\seldun.exe` in place of `seldun` unless its
folder has been added to PATH.

## Project layout

```text
Seldun/
  src/main.cpp              Native compiler and virtual machine
  examples/hello.sld        Small first program
  examples/features.sld     Complete language demonstration
  tests/language_test.sld   Automated language test input
  CMakeLists.txt            Cross-platform build definition
  build-windows.bat         Windows build helper
  build-linux-macos.sh      Linux/macOS build helper
  test-windows.bat          Windows test suite
  test-linux-macos.sh       Linux/macOS test suite
  LANGUAGE.md               Syntax reference
  LICENSE                   MIT license
```

## Ownership note

This package establishes the implementation and authorship notice, but a name,
copyright, or trademark may require separate legal registration or clearance.
