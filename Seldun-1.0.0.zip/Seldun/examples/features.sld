fn square(number) {
    return number * number;
}

let name = "Deonte";
say "Welcome to Seldun, " + name + "!";

let count = 1;
while (count <= 5) {
    say "Square " + count + " = " + square(count);
    count = count + 1;
}

if (square(5) == 25 and true) {
    say "Functions, loops, variables, and conditions are working.";
} else {
    say "Test failed.";
}

