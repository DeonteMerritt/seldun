# My first Seldun program
say "Seldun is its own programming language.";
say "It does not require Java or Python.";

