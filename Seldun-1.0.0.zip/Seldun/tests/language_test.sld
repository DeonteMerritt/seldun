fn add(a, b) { return a + b; }
let x = 2;
let total = 0;
while (x <= 4) { total = total + x; x = x + 1; }
say add(total, 10);
say 7 % 4;
say !false;
say "Sel" + "dun";

