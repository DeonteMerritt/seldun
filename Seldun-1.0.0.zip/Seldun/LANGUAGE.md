# Seldun 1.0 Language Reference

## Files

`.sld` contains human-readable source. `.slbc` contains compiled Seldun
bytecode and begins with the `SLBC` file signature.

## Grammar

```text
program     := (function | statement)* EOF
function    := "fn" IDENT "(" parameters? ")" block
parameters  := IDENT ("," IDENT)*
block       := "{" statement* "}"
statement   := "let" IDENT "=" expression ";"
             | "say" expression ";"
             | "if" "(" expression ")" block ("else" block)?
             | "while" "(" expression ")" block
             | "return" expression? ";"
             | expression ";"
expression  := assignment, logic, comparison, arithmetic, unary, or primary
```

Operator precedence, highest last: assignment; `or`; `and`; equality;
comparison; `+ -`; `* / %`; unary `! -`; parentheses, literals, names, calls.

## Values and truth

Numbers are double-precision. Strings use double quotes and support `\n`, `\t`,
`\"`, and `\\`. Only `false` and `nil` are false in conditions. Variables at
top level are global; variables created inside a function are local.

`+` adds two numbers. When its left operand is a string it concatenates the
display form of the right operand, making expressions such as
`"Score: " + score` valid.

## Current limits

Seldun 1.0 intentionally has no classes, arrays, imports, closures, package
manager, debugger, or native-code backend yet. Function declarations are
top-level. These are roadmap features, not claims about the current compiler.

