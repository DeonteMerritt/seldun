#!/usr/bin/env sh
set -eu
BIN="${1:-build/seldun}"
"$BIN" run tests/language_test.sld > tests/actual.txt
diff -u tests/expected.txt tests/actual.txt
"$BIN" compile tests/language_test.sld -o tests/language_test.slbc
"$BIN" exec tests/language_test.slbc > tests/bytecode-actual.txt
diff -u tests/expected.txt tests/bytecode-actual.txt
echo "All Seldun tests passed."

