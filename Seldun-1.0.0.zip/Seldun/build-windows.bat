@echo off
where cmake >nul 2>nul || (echo CMake was not found. Install it from https://cmake.org/download/ & exit /b 1)
cmake -S . -B build
cmake --build build --config Release
echo.
echo Seldun is ready in build\Release\seldun.exe

