#include <cmath>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <variant>
#include <vector>

namespace seldun {

struct Error : std::runtime_error { using std::runtime_error::runtime_error; };

enum class Tok { End, Number, String, Id, Let, Say, If, Else, While, True, False,
  Nil, And, Or, Fn, Return, LParen, RParen, LBrace, RBrace, Comma, Semicolon,
  Plus, Minus, Star, Slash, Percent, Bang, Equal, EqEq, BangEq, Less, LessEq,
  Greater, GreaterEq };
struct Token { Tok kind; std::string text; double number=0; int line=1; };

class Lexer {
  std::string s; size_t i=0; int line=1;
  char peek(size_t n=0) const { return i+n<s.size()?s[i+n]:'\0'; }
  char take(){ char c=peek(); if(c){++i;if(c=='\n')++line;} return c; }
public:
  explicit Lexer(std::string x):s(std::move(x)){}
  std::vector<Token> scan(){
    std::vector<Token> out;
    const std::unordered_map<std::string,Tok> kw={{"let",Tok::Let},{"say",Tok::Say},
      {"if",Tok::If},{"else",Tok::Else},{"while",Tok::While},{"true",Tok::True},
      {"false",Tok::False},{"nil",Tok::Nil},{"and",Tok::And},{"or",Tok::Or},
      {"fn",Tok::Fn},{"return",Tok::Return}};
    while(i<s.size()){
      char c=peek();
      if(c==' '||c=='\t'||c=='\r'||c=='\n'){take();continue;}
      if(c=='#'||(c=='/'&&peek(1)=='/')){while(peek()&&peek()!='\n')take();continue;}
      int ln=line;
      if(std::isdigit((unsigned char)c)){
        size_t b=i; while(std::isdigit((unsigned char)peek()))take();
        if(peek()=='.'&&std::isdigit((unsigned char)peek(1))){take();while(std::isdigit((unsigned char)peek()))take();}
        std::string t=s.substr(b,i-b); out.push_back({Tok::Number,t,std::stod(t),ln}); continue;
      }
      if(std::isalpha((unsigned char)c)||c=='_'){
        size_t b=i; while(std::isalnum((unsigned char)peek())||peek()=='_')take();
        std::string t=s.substr(b,i-b); auto k=kw.find(t); out.push_back({k==kw.end()?Tok::Id:k->second,t,0,ln}); continue;
      }
      if(c=='"'){
        take(); std::string v;
        while(peek()&&peek()!='"'){
          char q=take(); if(q=='\\'){char e=take(); if(e=='n')v+='\n';else if(e=='t')v+='\t';else if(e=='"')v+='"';else if(e=='\\')v+='\\';else throw Error("line "+std::to_string(ln)+": invalid escape");} else v+=q;
        }
        if(!peek()) throw Error("line "+std::to_string(ln)+": unterminated string");
        take(); out.push_back({Tok::String,v,0,ln});continue;
      }
      auto add=[&](Tok k,std::string t){out.push_back({k,std::move(t),0,ln});}; take();
      switch(c){
        case '(':add(Tok::LParen,"(");break; case ')':add(Tok::RParen,")");break;
        case '{':add(Tok::LBrace,"{");break; case '}':add(Tok::RBrace,"}");break;
        case ',':add(Tok::Comma,",");break; case ';':add(Tok::Semicolon,";");break;
        case '+':add(Tok::Plus,"+");break; case '-':add(Tok::Minus,"-");break;
        case '*':add(Tok::Star,"*");break; case '/':add(Tok::Slash,"/");break;
        case '%':add(Tok::Percent,"%");break;
        case '!':if(peek()=='='){take();add(Tok::BangEq,"!=");}else add(Tok::Bang,"!");break;
        case '=':if(peek()=='='){take();add(Tok::EqEq,"==");}else add(Tok::Equal,"=");break;
        case '<':if(peek()=='='){take();add(Tok::LessEq,"<=");}else add(Tok::Less,"<");break;
        case '>':if(peek()=='='){take();add(Tok::GreaterEq,">=");}else add(Tok::Greater,">");break;
        default:throw Error("line "+std::to_string(ln)+": unexpected character '"+c+"'");
      }
    }
    out.push_back({Tok::End,"",0,line}); return out;
  }
};

using Value=std::variant<std::monostate,double,bool,std::string>;
enum class Op:uint8_t { Constant,Nil,True,False,Pop,Get,Define,Set,Add,Sub,Mul,Div,Mod,
  Neg,Not,Equal,Less,Greater,Print,Jump,JumpFalse,Loop,Call,Return,Halt };
struct Ins { Op op; int a=0; };
struct Function { std::string name; int arity=0; std::vector<Ins> code; std::vector<Value> constants; std::vector<std::string> names; };
struct Program { std::vector<Function> functions; };

class Compiler {
  std::vector<Token> t; size_t p=0; Program prog; Function* f=nullptr;
  const Token& cur()const{return t[p];} const Token& prev()const{return t[p-1];}
  bool at(Tok k)const{return cur().kind==k;} bool match(Tok k){if(!at(k))return false;++p;return true;}
  const Token& need(Tok k,const std::string&m){if(!at(k))fail(cur(),m);return t[p++];}
  [[noreturn]] void fail(const Token&x,const std::string&m)const{throw Error("line "+std::to_string(x.line)+": "+m);}
  int emit(Op op,int a=0){f->code.push_back({op,a});return (int)f->code.size()-1;}
  int con(Value v){f->constants.push_back(std::move(v));return (int)f->constants.size()-1;}
  int name(const std::string&n){for(size_t i=0;i<f->names.size();++i)if(f->names[i]==n)return (int)i;f->names.push_back(n);return (int)f->names.size()-1;}
  void patch(int at){f->code[at].a=(int)f->code.size();}
  void semi(){need(Tok::Semicolon,"expected ';'");}
  void expr(){assignment();}
  void assignment(){
    if(at(Tok::Id)&&p+1<t.size()&&t[p+1].kind==Tok::Equal){std::string n=cur().text;p+=2;assignment();emit(Op::Set,name(n));return;} logicOr();
  }
  void logicOr(){logicAnd();while(match(Tok::Or)){int jf=emit(Op::JumpFalse);int j=emit(Op::Jump);patch(jf);emit(Op::Pop);logicAnd();patch(j);}}
  void logicAnd(){equality();while(match(Tok::And)){int j=emit(Op::JumpFalse);emit(Op::Pop);equality();patch(j);}}
  void equality(){comparison();while(at(Tok::EqEq)||at(Tok::BangEq)){Tok k=cur().kind;++p;comparison();emit(Op::Equal);if(k==Tok::BangEq)emit(Op::Not);}}
  void comparison(){term();while(at(Tok::Less)||at(Tok::LessEq)||at(Tok::Greater)||at(Tok::GreaterEq)){Tok k=cur().kind;++p;term();if(k==Tok::Less)emit(Op::Less);else if(k==Tok::Greater)emit(Op::Greater);else if(k==Tok::LessEq){emit(Op::Greater);emit(Op::Not);}else{emit(Op::Less);emit(Op::Not);}}}
  void term(){factor();while(at(Tok::Plus)||at(Tok::Minus)){Tok k=cur().kind;++p;factor();emit(k==Tok::Plus?Op::Add:Op::Sub);}}
  void factor(){unary();while(at(Tok::Star)||at(Tok::Slash)||at(Tok::Percent)){Tok k=cur().kind;++p;unary();emit(k==Tok::Star?Op::Mul:k==Tok::Slash?Op::Div:Op::Mod);}}
  void unary(){if(match(Tok::Bang)){unary();emit(Op::Not);}else if(match(Tok::Minus)){unary();emit(Op::Neg);}else primary();}
  void primary(){
    if(match(Tok::Number)){emit(Op::Constant,con(prev().number));return;}
    if(match(Tok::String)){emit(Op::Constant,con(prev().text));return;}
    if(match(Tok::True)){emit(Op::True);return;} if(match(Tok::False)){emit(Op::False);return;} if(match(Tok::Nil)){emit(Op::Nil);return;}
    if(match(Tok::LParen)){expr();need(Tok::RParen,"expected ')'");return;}
    if(match(Tok::Id)){std::string n=prev().text;if(match(Tok::LParen)){int argc=0;if(!at(Tok::RParen)){do{expr();++argc;}while(match(Tok::Comma));}need(Tok::RParen,"expected ')' after arguments");emit(Op::Call,(name(n)<<8)|argc);}else emit(Op::Get,name(n));return;}
    fail(cur(),"expected expression");
  }
  void block(){while(!at(Tok::RBrace)&&!at(Tok::End))statement();need(Tok::RBrace,"expected '}'");}
  void statement(){
    if(match(Tok::Let)){auto n=need(Tok::Id,"expected variable name").text;need(Tok::Equal,"expected '=' after variable name");expr();semi();emit(Op::Define,name(n));return;}
    if(match(Tok::Say)){expr();semi();emit(Op::Print);return;}
    if(match(Tok::If)){need(Tok::LParen,"expected '('");expr();need(Tok::RParen,"expected ')'");int jf=emit(Op::JumpFalse);emit(Op::Pop);need(Tok::LBrace,"expected '{'");block();int je=emit(Op::Jump);patch(jf);emit(Op::Pop);if(match(Tok::Else)){need(Tok::LBrace,"expected '{'");block();}patch(je);return;}
    if(match(Tok::While)){int start=(int)f->code.size();need(Tok::LParen,"expected '('");expr();need(Tok::RParen,"expected ')'");int exit=emit(Op::JumpFalse);emit(Op::Pop);need(Tok::LBrace,"expected '{'");block();emit(Op::Loop,start);patch(exit);emit(Op::Pop);return;}
    if(match(Tok::Return)){if(at(Tok::Semicolon))emit(Op::Nil);else expr();semi();emit(Op::Return);return;}
    expr();semi();emit(Op::Pop);
  }
  void function(){
    auto n=need(Tok::Id,"expected function name").text; Function fun;fun.name=n;
    need(Tok::LParen,"expected '('");std::vector<std::string> args;if(!at(Tok::RParen)){do{args.push_back(need(Tok::Id,"expected parameter name").text);}while(match(Tok::Comma));}need(Tok::RParen,"expected ')'");
    fun.arity=(int)args.size();need(Tok::LBrace,"expected '{'");Function* old=f;f=&fun;for(auto&a:args)name(a);block();emit(Op::Nil);emit(Op::Return);prog.functions.push_back(std::move(fun));f=old;
  }
public:
  explicit Compiler(std::vector<Token>x):t(std::move(x)){}
  Program compile(){prog.functions.reserve(64);Function main;main.name="<main>";prog.functions.push_back(std::move(main));f=&prog.functions[0];while(!at(Tok::End)){if(match(Tok::Fn))function();else statement();}emit(Op::Halt);return std::move(prog);}
};

static bool truth(const Value&v){if(std::holds_alternative<std::monostate>(v))return false;if(auto b=std::get_if<bool>(&v))return *b;return true;}
static std::string show(const Value&v){if(std::holds_alternative<std::monostate>(v))return "nil";if(auto n=std::get_if<double>(&v)){std::ostringstream o;o<<std::setprecision(15)<<*n;return o.str();}if(auto b=std::get_if<bool>(&v))return *b?"true":"false";return std::get<std::string>(v);}
class VM {
  Program prog; std::unordered_map<std::string,Value> globals;
  Value runfun(int fi,std::vector<Value> args){
    auto&fn=prog.functions.at(fi);if((int)args.size()!=fn.arity)throw Error(fn.name+" expects "+std::to_string(fn.arity)+" arguments");
    std::unordered_map<std::string,Value> vars;for(int i=0;i<fn.arity;++i)vars[fn.names[i]]=args[i];std::vector<Value> st;size_t ip=0;
    auto pop=[&](){if(st.empty())throw Error("VM stack underflow");Value v=st.back();st.pop_back();return v;};
    auto number=[&](Value v){if(auto n=std::get_if<double>(&v))return *n;throw Error("expected a number, got "+show(v));};
    auto getname=[&](int x)->Value{std::string n=fn.names.at(x);auto a=vars.find(n);if(a!=vars.end())return a->second;auto g=globals.find(n);if(g!=globals.end())return g->second;throw Error("undefined name '"+n+"'");};
    while(ip<fn.code.size()){
      Ins z=fn.code[ip++];
      switch(z.op){
        case Op::Constant:st.push_back(fn.constants.at(z.a));break;case Op::Nil:st.emplace_back();break;case Op::True:st.push_back(true);break;case Op::False:st.push_back(false);break;case Op::Pop:pop();break;
        case Op::Get:st.push_back(getname(z.a));break;case Op::Define:{Value v=pop();if(fi==0)globals[fn.names[z.a]]=v;else vars[fn.names[z.a]]=v;break;}
        case Op::Set:{if(st.empty())throw Error("assignment stack error");std::string n=fn.names[z.a];if(vars.count(n))vars[n]=st.back();else if(globals.count(n))globals[n]=st.back();else throw Error("cannot assign undefined name '"+n+"'");break;}
        case Op::Add:{Value b=pop(),a=pop();if(auto x=std::get_if<double>(&a)){st.push_back(*x+number(b));}else if(auto x=std::get_if<std::string>(&a)){st.push_back(*x+show(b));}else throw Error("'+' needs numbers or a string on the left");break;}
        case Op::Sub:{double b=number(pop()),a=number(pop());st.push_back(a-b);break;}case Op::Mul:{double b=number(pop()),a=number(pop());st.push_back(a*b);break;}case Op::Div:{double b=number(pop()),a=number(pop());if(b==0)throw Error("division by zero");st.push_back(a/b);break;}case Op::Mod:{double b=number(pop()),a=number(pop());if(b==0)throw Error("division by zero");st.push_back(std::fmod(a,b));break;}
        case Op::Neg:st.push_back(-number(pop()));break;case Op::Not:st.push_back(!truth(pop()));break;case Op::Equal:{auto b=pop(),a=pop();st.push_back(a==b);break;}case Op::Less:{double b=number(pop()),a=number(pop());st.push_back(a<b);break;}case Op::Greater:{double b=number(pop()),a=number(pop());st.push_back(a>b);break;}
        case Op::Print:std::cout<<show(pop())<<'\n';break;case Op::Jump:ip=z.a;break;case Op::JumpFalse:if(!truth(st.back()))ip=z.a;break;case Op::Loop:ip=z.a;break;
        case Op::Call:{int argc=z.a&255;std::string n=fn.names.at(z.a>>8);std::vector<Value>a(argc);for(int k=argc-1;k>=0;--k)a[k]=pop();if(n=="clock"){if(argc)throw Error("clock expects 0 arguments");st.push_back((double)std::clock()/CLOCKS_PER_SEC);}else{int target=-1;for(size_t k=1;k<prog.functions.size();++k)if(prog.functions[k].name==n)target=(int)k;if(target<0)throw Error("undefined function '"+n+"'");st.push_back(runfun(target,std::move(a)));}break;}
        case Op::Return:return pop();case Op::Halt:return Value{};
      }
    }return Value{};
  }
public:explicit VM(Program p):prog(std::move(p)){} void run(){runfun(0,{});}
};

template<class T>void writeRaw(std::ostream&o,const T&v){o.write(reinterpret_cast<const char*>(&v),sizeof v);}
template<class T>T readRaw(std::istream&i){T v{};i.read(reinterpret_cast<char*>(&v),sizeof v);if(!i)throw Error("damaged bytecode file");return v;}
void writeString(std::ostream&o,const std::string&s){uint32_t n=(uint32_t)s.size();writeRaw(o,n);o.write(s.data(),n);}
std::string readString(std::istream&i){uint32_t n=readRaw<uint32_t>(i);if(n>10000000)throw Error("damaged bytecode string");std::string s(n,'\0');i.read(s.data(),n);if(!i)throw Error("damaged bytecode file");return s;}
void save(const Program&p,const std::string&path){std::ofstream o(path,std::ios::binary);if(!o)throw Error("cannot write "+path);o.write("SLBC",4);writeRaw<uint16_t>(o,1);writeRaw<uint32_t>(o,(uint32_t)p.functions.size());for(auto&f:p.functions){writeString(o,f.name);writeRaw<int32_t>(o,f.arity);writeRaw<uint32_t>(o,(uint32_t)f.names.size());for(auto&s:f.names)writeString(o,s);writeRaw<uint32_t>(o,(uint32_t)f.constants.size());for(auto&v:f.constants){uint8_t tag=(uint8_t)v.index();writeRaw(o,tag);if(tag==1)writeRaw(o,std::get<double>(v));else if(tag==2)writeRaw<uint8_t>(o,std::get<bool>(v));else if(tag==3)writeString(o,std::get<std::string>(v));}writeRaw<uint32_t>(o,(uint32_t)f.code.size());for(auto&z:f.code){writeRaw<uint8_t>(o,(uint8_t)z.op);writeRaw<int32_t>(o,z.a);}}}
Program load(const std::string&path){std::ifstream i(path,std::ios::binary);if(!i)throw Error("cannot open "+path);char m[4];i.read(m,4);if(std::string(m,4)!="SLBC"||readRaw<uint16_t>(i)!=1)throw Error("not Seldun bytecode version 1");Program p;uint32_t nf=readRaw<uint32_t>(i);for(uint32_t q=0;q<nf;++q){Function f;f.name=readString(i);f.arity=readRaw<int32_t>(i);uint32_t nn=readRaw<uint32_t>(i);while(nn--)f.names.push_back(readString(i));uint32_t nc=readRaw<uint32_t>(i);while(nc--){uint8_t tag=readRaw<uint8_t>(i);if(tag==0)f.constants.emplace_back();else if(tag==1)f.constants.push_back(readRaw<double>(i));else if(tag==2)f.constants.push_back((bool)readRaw<uint8_t>(i));else if(tag==3)f.constants.push_back(readString(i));else throw Error("damaged bytecode constant");}uint32_t ni=readRaw<uint32_t>(i);while(ni--){auto op=(Op)readRaw<uint8_t>(i);int a=readRaw<int32_t>(i);f.code.push_back({op,a});}p.functions.push_back(std::move(f));}return p;}
std::string readFile(const std::string&p){std::ifstream i(p);if(!i)throw Error("cannot open "+p);std::ostringstream s;s<<i.rdbuf();return s.str();}
Program compileFile(const std::string&p){return Compiler(Lexer(readFile(p)).scan()).compile();}
}

int main(int argc,char**argv){using namespace seldun;try{
  if(argc<2){std::cout<<"Seldun 1.0\nUsage:\n  seldun run file.sld\n  seldun compile file.sld [-o file.slbc]\n  seldun exec file.slbc\n";return 0;}
  std::string cmd=argv[1];
  if(cmd=="--version"||cmd=="version"){std::cout<<"Seldun 1.0.0\n";return 0;}
  if(cmd=="run"&&argc==3){VM(compileFile(argv[2])).run();return 0;}
  if(cmd=="exec"&&argc==3){VM(load(argv[2])).run();return 0;}
  if(cmd=="compile"&&argc>=3){std::string out=std::string(argv[2])+".slbc";if(argc==5&&std::string(argv[3])=="-o")out=argv[4];save(compileFile(argv[2]),out);std::cout<<"Compiled "<<argv[2]<<" -> "<<out<<"\n";return 0;}
  std::cerr<<"Invalid command. Run 'seldun' for help.\n";return 2;
}catch(const Error&e){std::cerr<<"Seldun error: "<<e.what()<<'\n';return 1;}catch(const std::exception&e){std::cerr<<"System error: "<<e.what()<<'\n';return 1;}}
