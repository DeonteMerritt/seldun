@echo off
set BIN=build\Release\seldun.exe
if not exist "%BIN%" (echo Build Seldun first with build-windows.bat & exit /b 1)
"%BIN%" run tests\language_test.sld > tests\actual.txt
fc /b tests\expected.txt tests\actual.txt >nul || (echo Source execution test failed & exit /b 1)
"%BIN%" compile tests\language_test.sld -o tests\language_test.slbc || exit /b 1
"%BIN%" exec tests\language_test.slbc > tests\bytecode-actual.txt
fc /b tests\expected.txt tests\bytecode-actual.txt >nul || (echo Bytecode test failed & exit /b 1)
echo All Seldun tests passed.

