#ifndef SELDUN_VM_H
#define SELDUN_VM_H

#include "program.h"

int vm_run(Program *program, const char *file);

#endif
