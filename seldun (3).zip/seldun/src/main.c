#include "codegen.h"
#include "parser.h"
#include "sema.h"
#include "vm.h"

#include <limits.h>

static const char *SELDUN_VERSION = "0.1.0";

static void usage(FILE *out) {
    fprintf(out,
            "Seldun compiler %s\n"
            "\n"
            "Usage:\n"
            "  seldun run <file.sld>     Compile and run a program\n"
            "  seldun check <file.sld>   Parse and typecheck only\n"
            "  seldun dump <file.sld>    Print compiled bytecode\n"
            "  seldun <file.sld>         Compile and run a program\n"
            "  seldun help\n"
            "  seldun version\n",
            SELDUN_VERSION);
}

static char *read_file(const char *path, int *out_len) {
    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        fprintf(stderr, "cannot open '%s': %s\n", path, strerror(errno));
        return NULL;
    }
    if (fseek(file, 0, SEEK_END) != 0) {
        fprintf(stderr, "cannot read '%s'\n", path);
        fclose(file);
        return NULL;
    }
    long size = ftell(file);
    if (size < 0 || size > INT_MAX) {
        fprintf(stderr, "cannot read '%s'\n", path);
        fclose(file);
        return NULL;
    }
    if (fseek(file, 0, SEEK_SET) != 0) {
        fprintf(stderr, "cannot read '%s'\n", path);
        fclose(file);
        return NULL;
    }
    char *buf = (char *)malloc((size_t)size + 1);
    if (buf == NULL) {
        fprintf(stderr, "out of memory\n");
        fclose(file);
        return NULL;
    }
    size_t nread = fread(buf, 1, (size_t)size, file);
    fclose(file);
    buf[nread] = '\0';
    if (nread >= 3 && (unsigned char)buf[0] == 0xEFu && (unsigned char)buf[1] == 0xBBu &&
        (unsigned char)buf[2] == 0xBFu) {
        memmove(buf, buf + 3, nread - 3 + 1);
        nread -= 3;
    }
    *out_len = (int)nread;
    return buf;
}

static int ends_with(const char *text, const char *suffix) {
    size_t n = strlen(text);
    size_t m = strlen(suffix);
    if (m > n) {
        return 0;
    }
    return memcmp(text + (n - m), suffix, m) == 0;
}

static int compile_file(const char *path, const char *mode) {
    int length = 0;
    char *source = read_file(path, &length);
    if (source == NULL) {
        return 1;
    }
    Arena arena;
    memset(&arena, 0, sizeof(arena));
    Diag diag;
    diag.file = path;
    diag.errors = 0;
    Parsed parsed = parse_source(path, source, length, &arena, &diag);
    if (diag.errors == 0) {
        sema_check(&parsed, &arena, &diag);
    }
    Program *program = NULL;
    if (diag.errors == 0) {
        program = codegen_compile(&parsed, &diag);
    }
    int code = 1;
    if (diag.errors == 0 && program != NULL) {
        if (strcmp(mode, "check") == 0) {
            code = 0;
        } else if (strcmp(mode, "dump") == 0) {
            program_dump(program, stdout);
            code = 0;
        } else {
            code = vm_run(program, path);
        }
    }
    program_free(program);
    arena_free(&arena);
    free(source);
    return code;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        usage(stderr);
        return 1;
    }
    if (strcmp(argv[1], "help") == 0 || strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
        usage(stdout);
        return 0;
    }
    if (strcmp(argv[1], "version") == 0 || strcmp(argv[1], "--version") == 0 ||
        strcmp(argv[1], "-V") == 0) {
        printf("seldun %s\n", SELDUN_VERSION);
        return 0;
    }
    const char *mode = "run";
    const char *path = NULL;
    if (strcmp(argv[1], "run") == 0 || strcmp(argv[1], "check") == 0 || strcmp(argv[1], "dump") == 0) {
        if (argc != 3) {
            usage(stderr);
            return 1;
        }
        mode = argv[1];
        path = argv[2];
    } else if (ends_with(argv[1], ".sld") || ends_with(argv[1], ".sldc")) {
        if (argc != 2) {
            usage(stderr);
            return 1;
        }
        path = argv[1];
    } else {
        fprintf(stderr, "unknown command '%s'\n", argv[1]);
        usage(stderr);
        return 1;
    }
    return compile_file(path, mode);
}
