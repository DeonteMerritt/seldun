#include "common.h"

void *arena_alloc(Arena *arena, size_t size) {
    if (size == 0) {
        size = 1;
    }
    for (;;) {
        if (arena->chunk != NULL) {
            size_t off = (arena->chunk->used + 7u) & ~(size_t)7u;
            if (off + size <= arena->chunk->cap) {
                void *ptr = arena->chunk->data + off;
                arena->chunk->used = off + size;
                memset(ptr, 0, size);
                return ptr;
            }
        }
        size_t cap = 65536;
        if (arena->chunk != NULL && arena->chunk->cap < (size_t)1024 * 1024) {
            cap = arena->chunk->cap * 2;
        }
        if (cap < size + 8) {
            cap = size + 8;
        }
        Chunk *chunk = (Chunk *)malloc(sizeof(Chunk) + cap);
        if (chunk == NULL) {
            fprintf(stderr, "out of memory\n");
            exit(1);
        }
        chunk->next = arena->chunk;
        chunk->used = 0;
        chunk->cap = cap;
        arena->chunk = chunk;
    }
}

char *arena_strndup(Arena *arena, const char *text, size_t len) {
    char *copy = (char *)arena_alloc(arena, len + 1);
    if (len > 0 && text != NULL) {
        memcpy(copy, text, len);
    }
    copy[len] = '\0';
    return copy;
}

void arena_free(Arena *arena) {
    Chunk *chunk = arena->chunk;
    while (chunk != NULL) {
        Chunk *next = chunk->next;
        free(chunk);
        chunk = next;
    }
    arena->chunk = NULL;
}

void diag_error(Diag *diag, int line, int col, const char *fmt, ...) {
    va_list args;
    const char *file = (diag->file != NULL) ? diag->file : "<input>";
    if (line > 0) {
        fprintf(stderr, "%s:%d:%d: error: ", file, line, col);
    } else {
        fprintf(stderr, "%s: error: ", file);
    }
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fputc('\n', stderr);
    diag->errors++;
}
