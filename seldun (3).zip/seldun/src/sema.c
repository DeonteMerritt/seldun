#include "sema.h"

typedef struct VarSym {
    const char *name;
    Type type;
    int slot;
    int mutable;
    int depth;
} VarSym;

typedef struct Sema {
    Arena *arena;
    Diag *diag;
    Parsed *parsed;
    Function *fn;
    VarSym *vars;
    int nvars;
    int capvars;
    int depth;
    int next_slot;
} Sema;

static const char *type_name(TypeKind kind) {
    switch (kind) {
    case TYPE_VOID: return "void";
    case TYPE_INT: return "int";
    case TYPE_FLOAT: return "float";
    case TYPE_BOOL: return "bool";
    case TYPE_STRING: return "string";
    case TYPE_ERROR: return "<error>";
    case TYPE_NONE: return "<unknown>";
    default: return "<unknown>";
    }
}

static int assignable(Type dst, Type src) {
    if (dst.kind == TYPE_ERROR || src.kind == TYPE_ERROR) {
        return 1;
    }
    if (dst.kind == TYPE_VOID || src.kind == TYPE_VOID) {
        return 0;
    }
    if (dst.kind == src.kind) {
        return 1;
    }
    if (dst.kind == TYPE_FLOAT && src.kind == TYPE_INT) {
        return 1;
    }
    return 0;
}

static void enter_scope(Sema *sema) {
    sema->depth++;
}

static void leave_scope(Sema *sema) {
    while (sema->nvars > 0 && sema->vars[sema->nvars - 1].depth == sema->depth) {
        sema->nvars--;
    }
    sema->depth--;
}

static int declare_var(Sema *sema, const char *name, Type type, int mutable, int line, int col) {
    for (int i = sema->nvars - 1; i >= 0; i--) {
        if (sema->vars[i].depth != sema->depth) {
            break;
        }
        if (strcmp(sema->vars[i].name, name) == 0) {
            diag_error(sema->diag, line, col, "'%s' is already defined in this scope", name);
            break;
        }
    }
    if (sema->next_slot >= 1024) {
        diag_error(sema->diag, line, col, "too many local variables in '%s'", sema->fn->name);
    }
    VarSym sym;
    memset(&sym, 0, sizeof(sym));
    sym.name = name;
    sym.type = type;
    sym.slot = sema->next_slot++;
    sym.mutable = mutable;
    sym.depth = sema->depth;
    DA_PUSH(sema->arena, sema->vars, sema->nvars, sema->capvars, sym);
    return sym.slot;
}

static int lookup_var(Sema *sema, const char *name, VarSym *out) {
    for (int i = sema->nvars - 1; i >= 0; i--) {
        if (strcmp(sema->vars[i].name, name) == 0) {
            *out = sema->vars[i];
            return 1;
        }
    }
    return 0;
}

static int find_func(const Parsed *parsed, const char *name) {
    for (int i = 0; i < parsed->nfuncs; i++) {
        if (strcmp(parsed->funcs[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

static int builtin_of(const char *name) {
    if (strcmp(name, "print") == 0) return BUILTIN_PRINT;
    if (strcmp(name, "println") == 0) return BUILTIN_PRINTLN;
    if (strcmp(name, "len") == 0) return BUILTIN_LEN;
    if (strcmp(name, "str") == 0) return BUILTIN_STR;
    return BUILTIN_NONE;
}

static int is_printable(TypeKind kind) {
    return kind == TYPE_INT || kind == TYPE_FLOAT || kind == TYPE_BOOL || kind == TYPE_STRING ||
           kind == TYPE_ERROR;
}

static void check_expr(Sema *sema, Expr *expr);

static void check_call(Sema *sema, Expr *expr) {
    int index = find_func(sema->parsed, expr->as.call.name);
    if (index >= 0) {
        Function *callee = &sema->parsed->funcs[index];
        expr->as.call.func = index;
        expr->as.call.builtin = BUILTIN_NONE;
        expr->type = callee->ret;
        if (expr->as.call.nargs != callee->nparams) {
            diag_error(sema->diag, expr->line, expr->col,
                       "function '%s' expects %d argument%s, got %d", callee->name, callee->nparams,
                       callee->nparams == 1 ? "" : "s", expr->as.call.nargs);
        }
        int n = expr->as.call.nargs < callee->nparams ? expr->as.call.nargs : callee->nparams;
        for (int i = 0; i < expr->as.call.nargs; i++) {
            check_expr(sema, expr->as.call.args[i]);
        }
        for (int i = 0; i < n; i++) {
            Expr *arg = expr->as.call.args[i];
            if (arg->type.kind == TYPE_VOID) {
                diag_error(sema->diag, arg->line, arg->col, "cannot pass a void value as an argument");
            } else if (!assignable(callee->params[i].type, arg->type)) {
                diag_error(sema->diag, arg->line, arg->col,
                           "argument %d of '%s' has type %s, expected %s", i + 1, callee->name,
                           type_name(arg->type.kind), type_name(callee->params[i].type.kind));
            }
        }
        return;
    }

    int builtin = builtin_of(expr->as.call.name);
    expr->as.call.func = -1;
    expr->as.call.builtin = builtin;
    if (builtin == BUILTIN_NONE) {
        diag_error(sema->diag, expr->line, expr->col, "undefined function '%s'", expr->as.call.name);
        expr->type.kind = TYPE_ERROR;
        for (int i = 0; i < expr->as.call.nargs; i++) {
            check_expr(sema, expr->as.call.args[i]);
        }
        return;
    }
    if (expr->as.call.nargs != 1) {
        diag_error(sema->diag, expr->line, expr->col, "'%s' expects 1 argument, got %d",
                   expr->as.call.name, expr->as.call.nargs);
    }
    if (expr->as.call.nargs >= 1) {
        check_expr(sema, expr->as.call.args[0]);
        Type argt = expr->as.call.args[0]->type;
        if (builtin == BUILTIN_LEN) {
            if (argt.kind != TYPE_STRING && argt.kind != TYPE_ERROR) {
                diag_error(sema->diag, expr->line, expr->col, "'len' expects a string, got %s",
                           type_name(argt.kind));
            }
            expr->type.kind = TYPE_INT;
        } else if (builtin == BUILTIN_STR) {
            if (!is_printable(argt.kind)) {
                diag_error(sema->diag, expr->line, expr->col, "'str' cannot convert %s",
                           type_name(argt.kind));
            }
            expr->type.kind = TYPE_STRING;
        } else {
            if (!is_printable(argt.kind)) {
                diag_error(sema->diag, expr->line, expr->col, "'%s' cannot print %s",
                           expr->as.call.name, type_name(argt.kind));
            }
            expr->type.kind = TYPE_VOID;
        }
    } else if (builtin == BUILTIN_LEN) {
        expr->type.kind = TYPE_INT;
    } else if (builtin == BUILTIN_STR) {
        expr->type.kind = TYPE_STRING;
    } else {
        expr->type.kind = TYPE_VOID;
    }
    for (int i = 1; i < expr->as.call.nargs; i++) {
        check_expr(sema, expr->as.call.args[i]);
    }
}

static void check_expr(Sema *sema, Expr *expr) {
    if (expr == NULL) {
        return;
    }
    switch (expr->kind) {
    case EXPR_INT:
        expr->type.kind = TYPE_INT;
        break;
    case EXPR_FLOAT:
        expr->type.kind = TYPE_FLOAT;
        break;
    case EXPR_BOOL:
        expr->type.kind = TYPE_BOOL;
        break;
    case EXPR_STRING:
        expr->type.kind = TYPE_STRING;
        break;
    case EXPR_VAR: {
        VarSym sym;
        if (!lookup_var(sema, expr->as.var.name, &sym)) {
            diag_error(sema->diag, expr->line, expr->col, "undefined variable '%s'", expr->as.var.name);
            expr->type.kind = TYPE_ERROR;
            expr->as.var.slot = -1;
            break;
        }
        expr->type = sym.type;
        expr->as.var.slot = sym.slot;
        break;
    }
    case EXPR_UNARY:
        check_expr(sema, expr->as.unary.expr);
        if (expr->as.unary.expr->type.kind == TYPE_ERROR) {
            expr->type.kind = TYPE_ERROR;
            break;
        }
        if (expr->as.unary.op == UN_NOT) {
            if (expr->as.unary.expr->type.kind != TYPE_BOOL) {
                diag_error(sema->diag, expr->line, expr->col, "'!' expects a bool, got %s",
                           type_name(expr->as.unary.expr->type.kind));
                expr->type.kind = TYPE_ERROR;
            } else {
                expr->type.kind = TYPE_BOOL;
            }
        } else if (expr->as.unary.expr->type.kind == TYPE_INT ||
                   expr->as.unary.expr->type.kind == TYPE_FLOAT) {
            expr->type = expr->as.unary.expr->type;
        } else {
            diag_error(sema->diag, expr->line, expr->col, "cannot negate %s",
                       type_name(expr->as.unary.expr->type.kind));
            expr->type.kind = TYPE_ERROR;
        }
        break;
    case EXPR_BINARY: {
        check_expr(sema, expr->as.binary.left);
        check_expr(sema, expr->as.binary.right);
        Type lt = expr->as.binary.left->type;
        Type rt = expr->as.binary.right->type;
        BinOp op = expr->as.binary.op;
        if (lt.kind == TYPE_ERROR || rt.kind == TYPE_ERROR) {
            expr->type.kind = TYPE_ERROR;
            break;
        }
        if (op == BIN_AND || op == BIN_OR) {
            if (lt.kind != TYPE_BOOL || rt.kind != TYPE_BOOL) {
                diag_error(sema->diag, expr->line, expr->col, "'%s' expects bool operands",
                           op == BIN_AND ? "&&" : "||");
                expr->type.kind = TYPE_ERROR;
            } else {
                expr->type.kind = TYPE_BOOL;
            }
            break;
        }
        if (op == BIN_ADD && lt.kind == TYPE_STRING && rt.kind == TYPE_STRING) {
            expr->type.kind = TYPE_STRING;
            break;
        }
        int left_num = lt.kind == TYPE_INT || lt.kind == TYPE_FLOAT;
        int right_num = rt.kind == TYPE_INT || rt.kind == TYPE_FLOAT;
        if (op == BIN_ADD || op == BIN_SUB || op == BIN_MUL || op == BIN_DIV || op == BIN_MOD) {
            if (op == BIN_MOD) {
                if (lt.kind == TYPE_INT && rt.kind == TYPE_INT) {
                    expr->type.kind = TYPE_INT;
                } else {
                    diag_error(sema->diag, expr->line, expr->col, "'%%' expects int operands");
                    expr->type.kind = TYPE_ERROR;
                }
                break;
            }
            if (lt.kind == TYPE_INT && rt.kind == TYPE_INT) {
                expr->type.kind = TYPE_INT;
            } else if (left_num && right_num) {
                expr->type.kind = TYPE_FLOAT;
            } else {
                diag_error(sema->diag, expr->line, expr->col, "cannot apply this operator to %s and %s",
                           type_name(lt.kind), type_name(rt.kind));
                expr->type.kind = TYPE_ERROR;
            }
            break;
        }
        if (op == BIN_EQ || op == BIN_NE) {
            if ((lt.kind == TYPE_STRING && rt.kind == TYPE_STRING) ||
                (lt.kind == TYPE_BOOL && rt.kind == TYPE_BOOL) || (left_num && right_num)) {
                expr->type.kind = TYPE_BOOL;
            } else {
                diag_error(sema->diag, expr->line, expr->col, "cannot compare %s and %s",
                           type_name(lt.kind), type_name(rt.kind));
                expr->type.kind = TYPE_ERROR;
            }
            break;
        }
        if (left_num && right_num) {
            expr->type.kind = TYPE_BOOL;
        } else {
            diag_error(sema->diag, expr->line, expr->col, "cannot compare %s and %s", type_name(lt.kind),
                       type_name(rt.kind));
            expr->type.kind = TYPE_ERROR;
        }
        break;
    }
    case EXPR_CALL:
        check_call(sema, expr);
        break;
    default:
        expr->type.kind = TYPE_ERROR;
        diag_error(sema->diag, expr->line, expr->col, "unsupported expression");
        break;
    }
}

static void check_cond(Sema *sema, Expr *expr, const char *what) {
    check_expr(sema, expr);
    if (expr->type.kind != TYPE_BOOL && expr->type.kind != TYPE_ERROR) {
        diag_error(sema->diag, expr->line, expr->col, "%s must be a bool, got %s", what,
                   type_name(expr->type.kind));
    }
}

static void check_stmt(Sema *sema, Stmt *stmt);

static int stmt_returns(const Stmt *stmt) {
    if (stmt == NULL) {
        return 0;
    }
    switch (stmt->kind) {
    case STMT_RETURN:
        return 1;
    case STMT_BLOCK:
        for (int i = 0; i < stmt->as.block.count; i++) {
            if (stmt_returns(stmt->as.block.items[i])) {
                return 1;
            }
        }
        return 0;
    case STMT_IF:
        if (stmt->as.ifs.else_br == NULL) {
            return 0;
        }
        return stmt_returns(stmt->as.ifs.then_br) && stmt_returns(stmt->as.ifs.else_br);
    default:
        return 0;
    }
}

static void check_stmt(Sema *sema, Stmt *stmt) {
    if (stmt == NULL) {
        return;
    }
    switch (stmt->kind) {
    case STMT_BLOCK:
        enter_scope(sema);
        for (int i = 0; i < stmt->as.block.count; i++) {
            check_stmt(sema, stmt->as.block.items[i]);
        }
        leave_scope(sema);
        break;
    case STMT_LET:
        check_expr(sema, stmt->as.let.init);
        if (stmt->as.let.init->type.kind == TYPE_VOID) {
            diag_error(sema->diag, stmt->line, stmt->col, "cannot initialize '%s' with a void value",
                       stmt->as.let.name);
            stmt->as.let.type.kind = TYPE_ERROR;
        } else if (stmt->as.let.type.kind == TYPE_NONE) {
            stmt->as.let.type = stmt->as.let.init->type;
        } else if (stmt->as.let.type.kind == TYPE_VOID) {
            diag_error(sema->diag, stmt->line, stmt->col, "variable '%s' cannot have type void",
                       stmt->as.let.name);
            stmt->as.let.type.kind = TYPE_ERROR;
        } else if (!assignable(stmt->as.let.type, stmt->as.let.init->type)) {
            diag_error(sema->diag, stmt->as.let.init->line, stmt->as.let.init->col,
                       "cannot initialize '%s' of type %s from %s", stmt->as.let.name,
                       type_name(stmt->as.let.type.kind), type_name(stmt->as.let.init->type.kind));
        }
        stmt->as.let.slot =
            declare_var(sema, stmt->as.let.name, stmt->as.let.type, stmt->as.let.mutable, stmt->line,
                        stmt->col);
        break;
    case STMT_ASSIGN: {
        check_expr(sema, stmt->as.assign.value);
        VarSym sym;
        if (!lookup_var(sema, stmt->as.assign.name, &sym)) {
            diag_error(sema->diag, stmt->line, stmt->col, "undefined variable '%s'", stmt->as.assign.name);
            stmt->as.assign.slot = -1;
            stmt->as.assign.type.kind = TYPE_ERROR;
            break;
        }
        if (!sym.mutable) {
            diag_error(sema->diag, stmt->line, stmt->col, "cannot assign to immutable binding '%s'",
                       stmt->as.assign.name);
        }
        if (stmt->as.assign.value->type.kind == TYPE_VOID) {
            diag_error(sema->diag, stmt->line, stmt->col, "cannot assign a void value to '%s'",
                       stmt->as.assign.name);
        } else if (!assignable(sym.type, stmt->as.assign.value->type)) {
            diag_error(sema->diag, stmt->as.assign.value->line, stmt->as.assign.value->col,
                       "cannot assign %s to '%s' of type %s",
                       type_name(stmt->as.assign.value->type.kind), stmt->as.assign.name,
                       type_name(sym.type.kind));
        }
        stmt->as.assign.slot = sym.slot;
        stmt->as.assign.type = sym.type;
        break;
    }
    case STMT_EXPR:
        check_expr(sema, stmt->as.expr);
        break;
    case STMT_IF:
        check_cond(sema, stmt->as.ifs.cond, "if condition");
        check_stmt(sema, stmt->as.ifs.then_br);
        check_stmt(sema, stmt->as.ifs.else_br);
        break;
    case STMT_WHILE:
        check_cond(sema, stmt->as.whiles.cond, "while condition");
        check_stmt(sema, stmt->as.whiles.body);
        break;
    case STMT_FOR:
        check_expr(sema, stmt->as.fors.start);
        check_expr(sema, stmt->as.fors.end);
        if (stmt->as.fors.start->type.kind != TYPE_INT && stmt->as.fors.start->type.kind != TYPE_ERROR) {
            diag_error(sema->diag, stmt->as.fors.start->line, stmt->as.fors.start->col,
                       "range start must be int, got %s", type_name(stmt->as.fors.start->type.kind));
        }
        if (stmt->as.fors.end->type.kind != TYPE_INT && stmt->as.fors.end->type.kind != TYPE_ERROR) {
            diag_error(sema->diag, stmt->as.fors.end->line, stmt->as.fors.end->col,
                       "range end must be int, got %s", type_name(stmt->as.fors.end->type.kind));
        }
        enter_scope(sema);
        {
            Type int_type;
            int_type.kind = TYPE_INT;
            stmt->as.fors.slot =
                declare_var(sema, stmt->as.fors.name, int_type, 0, stmt->line, stmt->col);
            stmt->as.fors.end_slot = sema->next_slot++;
        }
        check_stmt(sema, stmt->as.fors.body);
        leave_scope(sema);
        break;
    case STMT_RETURN:
        if (sema->fn->ret.kind == TYPE_VOID) {
            if (stmt->as.ret.value != NULL) {
                check_expr(sema, stmt->as.ret.value);
                diag_error(sema->diag, stmt->line, stmt->col, "void function '%s' cannot return a value",
                           sema->fn->name);
            }
        } else if (stmt->as.ret.value == NULL) {
            diag_error(sema->diag, stmt->line, stmt->col, "function '%s' must return a %s", sema->fn->name,
                       type_name(sema->fn->ret.kind));
        } else {
            check_expr(sema, stmt->as.ret.value);
            if (stmt->as.ret.value->type.kind == TYPE_VOID) {
                diag_error(sema->diag, stmt->line, stmt->col, "cannot return a void value");
            } else if (sema->fn->ret.kind != TYPE_ERROR &&
                       !assignable(sema->fn->ret, stmt->as.ret.value->type)) {
                diag_error(sema->diag, stmt->as.ret.value->line, stmt->as.ret.value->col,
                           "cannot return %s from '%s' (expected %s)",
                           type_name(stmt->as.ret.value->type.kind), sema->fn->name,
                           type_name(sema->fn->ret.kind));
            }
        }
        break;
    default:
        diag_error(sema->diag, stmt->line, stmt->col, "unsupported statement");
        break;
    }
}

static void check_function(Sema *sema, Function *fn) {
    sema->fn = fn;
    sema->nvars = 0;
    sema->depth = 0;
    sema->next_slot = 0;
    if (fn->ret.kind == TYPE_NONE) {
        fn->ret.kind = TYPE_VOID;
    }
    enter_scope(sema);
    for (int i = 0; i < fn->nparams; i++) {
        if (fn->params[i].type.kind == TYPE_VOID) {
            diag_error(sema->diag, fn->line, fn->col, "parameter '%s' cannot have type void",
                       fn->params[i].name);
            fn->params[i].type.kind = TYPE_ERROR;
        }
        fn->params[i].slot =
            declare_var(sema, fn->params[i].name, fn->params[i].type, 0, fn->line, fn->col);
    }
    check_stmt(sema, fn->body);
    leave_scope(sema);
    fn->nlocals = sema->next_slot;
    if (fn->ret.kind != TYPE_VOID && fn->ret.kind != TYPE_ERROR && !stmt_returns(fn->body)) {
        diag_error(sema->diag, fn->line, fn->col, "function '%s' must return a %s on every path",
                   fn->name, type_name(fn->ret.kind));
    }
}

int sema_check(Parsed *parsed, Arena *arena, Diag *diag) {
    Sema sema;
    memset(&sema, 0, sizeof(sema));
    sema.arena = arena;
    sema.diag = diag;
    sema.parsed = parsed;
    int main_count = 0;
    for (int i = 0; i < parsed->nfuncs; i++) {
        check_function(&sema, &parsed->funcs[i]);
        if (strcmp(parsed->funcs[i].name, "main") == 0) {
            main_count++;
            if (parsed->funcs[i].nparams != 0) {
                diag_error(diag, parsed->funcs[i].line, parsed->funcs[i].col,
                           "main takes no parameters");
            }
            TypeKind ret = parsed->funcs[i].ret.kind;
            if (ret != TYPE_VOID && ret != TYPE_INT && ret != TYPE_ERROR) {
                diag_error(diag, parsed->funcs[i].line, parsed->funcs[i].col,
                           "main must return int or void, not %s", type_name(ret));
            }
        }
    }
    if (main_count == 0) {
        diag_error(diag, 0, 0, "missing main function");
    }
    return diag->errors == 0;
}
