#ifndef SELDUN_COMMON_H
#define SELDUN_COMMON_H

#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Chunk {
    struct Chunk *next;
    size_t used;
    size_t cap;
    char data[];
} Chunk;

typedef struct Arena {
    Chunk *chunk;
} Arena;

void *arena_alloc(Arena *arena, size_t size);
char *arena_strndup(Arena *arena, const char *text, size_t len);
void arena_free(Arena *arena);

typedef struct Diag {
    const char *file;
    int errors;
} Diag;

#if defined(__GNUC__)
__attribute__((format(printf, 4, 5)))
#endif
void diag_error(Diag *diag, int line, int col, const char *fmt, ...);

#define DA_PUSH(arena, arr, count, cap, item)                                \
    do {                                                                     \
        if ((count) >= (cap)) {                                              \
            int seldun_new_cap_ = (cap) < 8 ? 8 : (cap) * 2;                 \
            void *seldun_new_mem_ =                                          \
                arena_alloc((arena), sizeof(*(arr)) * (size_t)seldun_new_cap_); \
            if ((arr) != NULL && (count) > 0) {                              \
                memcpy(seldun_new_mem_, (arr), sizeof(*(arr)) * (size_t)(count)); \
            }                                                                \
            (arr) = seldun_new_mem_;                                         \
            (cap) = seldun_new_cap_;                                         \
        }                                                                    \
        (arr)[(count)++] = (item);                                           \
    } while (0)

#endif
