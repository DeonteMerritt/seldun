#ifndef SELDUN_PROGRAM_H
#define SELDUN_PROGRAM_H

#include "common.h"

typedef enum OpCode {
    OP_NIL = 1,
    OP_TRUE,
    OP_FALSE,
    OP_CONST,
    OP_LOAD,
    OP_STORE,
    OP_POP,
    OP_DUP,
    OP_ADD_I,
    OP_SUB_I,
    OP_MUL_I,
    OP_DIV_I,
    OP_MOD_I,
    OP_NEG_I,
    OP_ADD_F,
    OP_SUB_F,
    OP_MUL_F,
    OP_DIV_F,
    OP_NEG_F,
    OP_I2F,
    OP_EQ_I,
    OP_NE_I,
    OP_LT_I,
    OP_GT_I,
    OP_LE_I,
    OP_GE_I,
    OP_EQ_F,
    OP_NE_F,
    OP_LT_F,
    OP_GT_F,
    OP_LE_F,
    OP_GE_F,
    OP_EQ_S,
    OP_NE_S,
    OP_EQ_B,
    OP_NE_B,
    OP_NOT,
    OP_CONCAT,
    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_JUMP_IF_TRUE,
    OP_CALL,
    OP_PRINT,
    OP_PRINTLN,
    OP_LEN,
    OP_STR,
    OP_RETURN
} OpCode;

typedef enum ValKind {
    VAL_NIL = 0,
    VAL_INT,
    VAL_FLOAT,
    VAL_BOOL,
    VAL_STR
} ValKind;

typedef struct Value {
    ValKind kind;
    int64_t i;
    double f;
    int b;
    const char *s;
    int slen;
} Value;

typedef struct CompiledFn {
    const char *name;
    uint8_t *code;
    int code_len;
    int *lines;
    int nlocals;
    int nparams;
} CompiledFn;

typedef struct Program {
    CompiledFn *fns;
    int nfn;
    Value *consts;
    int nconst;
    int main_index;
} Program;

void program_free(Program *program);
void program_dump(const Program *program, FILE *out);

#endif
