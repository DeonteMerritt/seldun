#ifndef SELDUN_AST_H
#define SELDUN_AST_H

#include "common.h"

typedef enum TypeKind {
    TYPE_NONE = 0,
    TYPE_VOID,
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_STRING,
    TYPE_ERROR
} TypeKind;

typedef struct Type {
    TypeKind kind;
} Type;

typedef enum BinOp {
    BIN_ADD,
    BIN_SUB,
    BIN_MUL,
    BIN_DIV,
    BIN_MOD,
    BIN_EQ,
    BIN_NE,
    BIN_LT,
    BIN_GT,
    BIN_LE,
    BIN_GE,
    BIN_AND,
    BIN_OR
} BinOp;

typedef enum UnOp {
    UN_NEG,
    UN_NOT
} UnOp;

typedef enum ExprKind {
    EXPR_INT,
    EXPR_FLOAT,
    EXPR_BOOL,
    EXPR_STRING,
    EXPR_VAR,
    EXPR_UNARY,
    EXPR_BINARY,
    EXPR_CALL
} ExprKind;

typedef struct Expr Expr;
typedef struct Stmt Stmt;

struct Expr {
    ExprKind kind;
    Type type;
    int line;
    int col;
    union {
        int64_t ival;
        double fval;
        int bval;
        struct {
            const char *data;
            int len;
        } str;
        struct {
            const char *name;
            int slot;
        } var;
        struct {
            UnOp op;
            Expr *expr;
        } unary;
        struct {
            BinOp op;
            Expr *left;
            Expr *right;
        } binary;
        struct {
            const char *name;
            Expr **args;
            int nargs;
            int func;
            int builtin;
        } call;
    } as;
};

typedef enum StmtKind {
    STMT_BLOCK,
    STMT_LET,
    STMT_ASSIGN,
    STMT_EXPR,
    STMT_IF,
    STMT_WHILE,
    STMT_FOR,
    STMT_RETURN
} StmtKind;

struct Stmt {
    StmtKind kind;
    int line;
    int col;
    union {
        struct {
            Stmt **items;
            int count;
        } block;
        struct {
            const char *name;
            Type type;
            int mutable;
            Expr *init;
            int slot;
        } let;
        struct {
            const char *name;
            Type type;
            Expr *value;
            int slot;
        } assign;
        Expr *expr;
        struct {
            Expr *cond;
            Stmt *then_br;
            Stmt *else_br;
        } ifs;
        struct {
            Expr *cond;
            Stmt *body;
        } whiles;
        struct {
            const char *name;
            Expr *start;
            Expr *end;
            Stmt *body;
            int slot;
            int end_slot;
        } fors;
        struct {
            Expr *value;
        } ret;
    } as;
};

typedef struct Param {
    const char *name;
    Type type;
    int slot;
} Param;

typedef struct Function {
    const char *name;
    Type ret;
    Param *params;
    int nparams;
    Stmt *body;
    int nlocals;
    int line;
    int col;
} Function;

typedef struct Parsed {
    Function *funcs;
    int nfuncs;
} Parsed;

#endif
