#include "lexer.h"

void lexer_init(Lexer *lexer, const char *src, int length, Arena *arena, Diag *diag) {
    lexer->src = src;
    lexer->length = length;
    lexer->pos = 0;
    lexer->line = 1;
    lexer->col = 1;
    lexer->arena = arena;
    lexer->diag = diag;
    if (length >= 3 && (unsigned char)src[0] == 0xEFu &&
        (unsigned char)src[1] == 0xBBu && (unsigned char)src[2] == 0xBFu) {
        lexer->pos = 3;
    }
}

static int at_end(const Lexer *lexer) {
    return lexer->pos >= lexer->length;
}

static char peek_at(const Lexer *lexer, int offset) {
    int index = lexer->pos + offset;
    if (index < 0 || index >= lexer->length) {
        return '\0';
    }
    return lexer->src[index];
}

static char advance_char(Lexer *lexer) {
    char c = lexer->src[lexer->pos++];
    if (c == '\n') {
        lexer->line++;
        lexer->col = 1;
        lexer->pending_nl = 1;
    } else if (c != '\r') {
        lexer->col++;
    }
    return c;
}

static int is_ident_start(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}

static int is_ident_cont(char c) {
    return is_ident_start(c) || (c >= '0' && c <= '9');
}

static Token make_token(Lexer *lexer, TokenKind kind, int line, int col, const char *lexeme, int lexeme_len) {
    Token token;
    memset(&token, 0, sizeof(token));
    token.kind = kind;
    token.line = line;
    token.col = col;
    token.lexeme = lexeme;
    token.lexeme_len = lexeme_len;
    token.text = lexeme;
    token.text_len = lexeme_len;
    token.follows_newline = lexer->pending_nl;
    lexer->pending_nl = 0;
    return token;
}

static int keyword_kind(const char *text, int len) {
    switch (len) {
    case 2:
        if (memcmp(text, "fn", 2) == 0) return TOK_FN;
        if (memcmp(text, "if", 2) == 0) return TOK_IF;
        if (memcmp(text, "in", 2) == 0) return TOK_IN;
        break;
    case 3:
        if (memcmp(text, "let", 3) == 0) return TOK_LET;
        if (memcmp(text, "var", 3) == 0) return TOK_VAR;
        if (memcmp(text, "for", 3) == 0) return TOK_FOR;
        if (memcmp(text, "int", 3) == 0) return TOK_INT_T;
        break;
    case 4:
        if (memcmp(text, "else", 4) == 0) return TOK_ELSE;
        if (memcmp(text, "true", 4) == 0) return TOK_TRUE;
        if (memcmp(text, "bool", 4) == 0) return TOK_BOOL_T;
        if (memcmp(text, "void", 4) == 0) return TOK_VOID_T;
        break;
    case 5:
        if (memcmp(text, "while", 5) == 0) return TOK_WHILE;
        if (memcmp(text, "false", 5) == 0) return TOK_FALSE;
        if (memcmp(text, "float", 5) == 0) return TOK_FLOAT_T;
        break;
    case 6:
        if (memcmp(text, "return", 6) == 0) return TOK_RETURN;
        if (memcmp(text, "string", 6) == 0) return TOK_STRING_T;
        break;
    default:
        break;
    }
    return TOK_IDENT;
}

static Token scan_string(Lexer *lexer, int line, int col) {
    char *buffer = NULL;
    int len = 0;
    int cap = 0;
    int closed = 0;
    while (!at_end(lexer)) {
        char c = peek_at(lexer, 0);
        if (c == '"') {
            advance_char(lexer);
            closed = 1;
            break;
        }
        if (c == '\n' || c == '\0') {
            break;
        }
        if (c == '\\') {
            advance_char(lexer);
            if (at_end(lexer)) {
                diag_error(lexer->diag, line, col, "unterminated string literal");
                break;
            }
            char esc = advance_char(lexer);
            char decoded = esc;
            int known = 1;
            switch (esc) {
            case 'n': decoded = '\n'; break;
            case 't': decoded = '\t'; break;
            case 'r': decoded = '\r'; break;
            case '\\': decoded = '\\'; break;
            case '"': decoded = '"'; break;
            case '0': decoded = '\0'; break;
            default:
                known = 0;
                diag_error(lexer->diag, lexer->line, lexer->col - 1, "unknown string escape '\\%c'", esc);
                break;
            }
            (void)known;
            if (len >= cap) {
                int new_cap = cap < 16 ? 16 : cap * 2;
                char *grown = (char *)realloc(buffer, (size_t)new_cap);
                if (grown == NULL) {
                    fprintf(stderr, "out of memory\n");
                    exit(1);
                }
                buffer = grown;
                cap = new_cap;
            }
            buffer[len++] = decoded;
            continue;
        }
        advance_char(lexer);
        if (len >= cap) {
            int new_cap = cap < 16 ? 16 : cap * 2;
            char *grown = (char *)realloc(buffer, (size_t)new_cap);
            if (grown == NULL) {
                fprintf(stderr, "out of memory\n");
                exit(1);
            }
            buffer = grown;
            cap = new_cap;
        }
        buffer[len++] = c;
    }
    if (!closed) {
        diag_error(lexer->diag, line, col, "unterminated string literal");
    }
    const char *text = arena_strndup(lexer->arena, buffer != NULL ? buffer : "", (size_t)len);
    free(buffer);
    Token token = make_token(lexer, TOK_STRING, line, col, text, len);
    token.text = text;
    token.text_len = len;
    return token;
}

static Token scan_number(Lexer *lexer, int line, int col) {
    int start = lexer->pos;
    while (!at_end(lexer) && peek_at(lexer, 0) >= '0' && peek_at(lexer, 0) <= '9') {
        advance_char(lexer);
    }
    int is_float = 0;
    if (!at_end(lexer) && peek_at(lexer, 0) == '.' && peek_at(lexer, 1) != '.') {
        if (peek_at(lexer, 1) >= '0' && peek_at(lexer, 1) <= '9') {
            is_float = 1;
            advance_char(lexer);
            while (!at_end(lexer) && peek_at(lexer, 0) >= '0' && peek_at(lexer, 0) <= '9') {
                advance_char(lexer);
            }
        }
    }
    int length = lexer->pos - start;
    char temp[128];
    if (length <= 0 || length >= (int)sizeof(temp)) {
        diag_error(lexer->diag, line, col, "numeric literal is too long");
        return make_token(lexer, is_float ? TOK_FLOAT : TOK_INT, line, col, lexer->src + start, length > 0 ? length : 0);
    }
    memcpy(temp, lexer->src + start, (size_t)length);
    temp[length] = '\0';
    Token token = make_token(lexer, is_float ? TOK_FLOAT : TOK_INT, line, col, lexer->src + start, length);
    if (is_float) {
        char *end = NULL;
        token.fval = strtod(temp, &end);
        if (end == temp) {
            diag_error(lexer->diag, line, col, "invalid float literal");
        }
    } else {
        errno = 0;
        char *end = NULL;
        long long value = strtoll(temp, &end, 10);
        if (end == temp || errno == ERANGE) {
            diag_error(lexer->diag, line, col, "integer literal out of range");
            value = 0;
        }
        token.ival = (int64_t)value;
    }
    return token;
}

Token lexer_next(Lexer *lexer) {
    for (;;) {
        if (at_end(lexer)) {
            return make_token(lexer, TOK_EOF, lexer->line, lexer->col, lexer->src + lexer->pos, 0);
        }
        char c = peek_at(lexer, 0);
        if (c == '\r') {
            advance_char(lexer);
            lexer->pending_nl = 1;
            if (!at_end(lexer) && peek_at(lexer, 0) == '\n') {
                advance_char(lexer);
            } else {
                lexer->line++;
                lexer->col = 1;
            }
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f') {
            advance_char(lexer);
            continue;
        }
        int line = lexer->line;
        int col = lexer->col;
        if (c == '/' && peek_at(lexer, 1) == '/') {
            while (!at_end(lexer) && peek_at(lexer, 0) != '\n') {
                advance_char(lexer);
            }
            continue;
        }
        if (c == '/' && peek_at(lexer, 1) == '*') {
            advance_char(lexer);
            advance_char(lexer);
            int closed = 0;
            while (!at_end(lexer)) {
                if (peek_at(lexer, 0) == '*' && peek_at(lexer, 1) == '/') {
                    advance_char(lexer);
                    advance_char(lexer);
                    closed = 1;
                    break;
                }
                advance_char(lexer);
            }
            if (!closed) {
                diag_error(lexer->diag, line, col, "unterminated block comment");
            }
            continue;
        }
        if (is_ident_start(c)) {
            int start = lexer->pos;
            advance_char(lexer);
            while (!at_end(lexer) && is_ident_cont(peek_at(lexer, 0))) {
                advance_char(lexer);
            }
            int length = lexer->pos - start;
            TokenKind kind = (TokenKind)keyword_kind(lexer->src + start, length);
            return make_token(lexer, kind, line, col, lexer->src + start, length);
        }
        if (c >= '0' && c <= '9') {
            return scan_number(lexer, line, col);
        }
        if (c == '"') {
            advance_char(lexer);
            return scan_string(lexer, line, col);
        }
        advance_char(lexer);
        char next = peek_at(lexer, 0);
        if (c == '=' && next == '=') {
            advance_char(lexer);
            return make_token(lexer, TOK_EQ, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '!' && next == '=') {
            advance_char(lexer);
            return make_token(lexer, TOK_NE, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '<' && next == '=') {
            advance_char(lexer);
            return make_token(lexer, TOK_LE, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '>' && next == '=') {
            advance_char(lexer);
            return make_token(lexer, TOK_GE, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '&' && next == '&') {
            advance_char(lexer);
            return make_token(lexer, TOK_AND, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '|' && next == '|') {
            advance_char(lexer);
            return make_token(lexer, TOK_OR, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '-' && next == '>') {
            advance_char(lexer);
            return make_token(lexer, TOK_ARROW, line, col, lexer->src + lexer->pos - 2, 2);
        }
        if (c == '.' && next == '.') {
            advance_char(lexer);
            return make_token(lexer, TOK_DOTDOT, line, col, lexer->src + lexer->pos - 2, 2);
        }
        switch (c) {
        case '+': return make_token(lexer, TOK_PLUS, line, col, lexer->src + lexer->pos - 1, 1);
        case '-': return make_token(lexer, TOK_MINUS, line, col, lexer->src + lexer->pos - 1, 1);
        case '*': return make_token(lexer, TOK_STAR, line, col, lexer->src + lexer->pos - 1, 1);
        case '/': return make_token(lexer, TOK_SLASH, line, col, lexer->src + lexer->pos - 1, 1);
        case '%': return make_token(lexer, TOK_PERCENT, line, col, lexer->src + lexer->pos - 1, 1);
        case '<': return make_token(lexer, TOK_LT, line, col, lexer->src + lexer->pos - 1, 1);
        case '>': return make_token(lexer, TOK_GT, line, col, lexer->src + lexer->pos - 1, 1);
        case '!': return make_token(lexer, TOK_NOT, line, col, lexer->src + lexer->pos - 1, 1);
        case '=': return make_token(lexer, TOK_ASSIGN, line, col, lexer->src + lexer->pos - 1, 1);
        case '(': return make_token(lexer, TOK_LPAREN, line, col, lexer->src + lexer->pos - 1, 1);
        case ')': return make_token(lexer, TOK_RPAREN, line, col, lexer->src + lexer->pos - 1, 1);
        case '{': return make_token(lexer, TOK_LBRACE, line, col, lexer->src + lexer->pos - 1, 1);
        case '}': return make_token(lexer, TOK_RBRACE, line, col, lexer->src + lexer->pos - 1, 1);
        case ',': return make_token(lexer, TOK_COMMA, line, col, lexer->src + lexer->pos - 1, 1);
        case ':': return make_token(lexer, TOK_COLON, line, col, lexer->src + lexer->pos - 1, 1);
        case ';': return make_token(lexer, TOK_SEMI, line, col, lexer->src + lexer->pos - 1, 1);
        default:
            break;
        }
        if (c >= 32 && c < 127) {
            diag_error(lexer->diag, line, col, "unexpected character '%c'", c);
        } else {
            diag_error(lexer->diag, line, col, "unexpected character 0x%02X", (unsigned char)c);
        }
    }
}
