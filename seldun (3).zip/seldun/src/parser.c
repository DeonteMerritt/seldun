#include "parser.h"

typedef struct Parser {
    Lexer lexer;
    Token cur;
    Token next;
    Token prev;
    Arena *arena;
    Diag *diag;
    Function *funcs;
    int nfuncs;
    int capfuncs;
    int panic;
} Parser;

static void advance(Parser *parser) {
    parser->prev = parser->cur;
    parser->cur = parser->next;
    parser->next = lexer_next(&parser->lexer);
    if (parser->diag->errors > 40 && parser->cur.kind != TOK_EOF) {
        Token eof = parser->cur;
        eof.kind = TOK_EOF;
        parser->cur = eof;
        parser->next = eof;
    }
}

static int check(const Parser *parser, TokenKind kind) {
    return parser->cur.kind == kind;
}

static int match(Parser *parser, TokenKind kind) {
    if (!check(parser, kind)) {
        return 0;
    }
    advance(parser);
    return 1;
}

static void error_at(Parser *parser, Token token, const char *fmt, ...) {
    if (parser->panic) {
        return;
    }
    va_list args;
    const char *file = parser->diag->file != NULL ? parser->diag->file : "<input>";
    fprintf(stderr, "%s:%d:%d: error: ", file, token.line, token.col);
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fputc('\n', stderr);
    parser->diag->errors++;
    parser->panic = 1;
}

static void expect(Parser *parser, TokenKind kind, const char *what) {
    if (match(parser, kind)) {
        parser->panic = 0;
        return;
    }
    error_at(parser, parser->cur, "expected %s", what);
}

static int at_stmt_end(const Parser *parser) {
    return parser->cur.follows_newline || parser->cur.kind == TOK_RBRACE || parser->cur.kind == TOK_EOF ||
           parser->cur.kind == TOK_SEMI;
}

static void expect_stmt_end(Parser *parser) {
    if (match(parser, TOK_SEMI)) {
        parser->panic = 0;
        return;
    }
    if (parser->cur.follows_newline || parser->cur.kind == TOK_RBRACE || parser->cur.kind == TOK_EOF) {
        parser->panic = 0;
        return;
    }
    error_at(parser, parser->cur, "expected ';' or a newline to end the statement");
}

static char *copy_token(Parser *parser, Token token) {
    const char *text = token.text != NULL ? token.text : "";
    int len = token.text_len;
    if (len < 0) {
        len = 0;
    }
    return arena_strndup(parser->arena, text, (size_t)len);
}

static Expr *new_expr(Parser *parser, ExprKind kind, int line, int col) {
    Expr *expr = (Expr *)arena_alloc(parser->arena, sizeof(Expr));
    expr->kind = kind;
    expr->line = line;
    expr->col = col;
    expr->type.kind = TYPE_NONE;
    return expr;
}

static Stmt *new_stmt(Parser *parser, StmtKind kind, int line, int col) {
    Stmt *stmt = (Stmt *)arena_alloc(parser->arena, sizeof(Stmt));
    stmt->kind = kind;
    stmt->line = line;
    stmt->col = col;
    return stmt;
}

static Expr *dummy_expr(Parser *parser) {
    return new_expr(parser, EXPR_INT, parser->cur.line, parser->cur.col);
}

static Stmt *parse_statement(Parser *parser);
static Expr *parse_expr(Parser *parser);

static Type parse_type(Parser *parser) {
    Type type;
    type.kind = TYPE_ERROR;
    if (match(parser, TOK_INT_T)) {
        type.kind = TYPE_INT;
    } else if (match(parser, TOK_FLOAT_T)) {
        type.kind = TYPE_FLOAT;
    } else if (match(parser, TOK_BOOL_T)) {
        type.kind = TYPE_BOOL;
    } else if (match(parser, TOK_STRING_T)) {
        type.kind = TYPE_STRING;
    } else if (match(parser, TOK_VOID_T)) {
        type.kind = TYPE_VOID;
    } else {
        error_at(parser, parser->cur, "expected a type");
    }
    return type;
}

static Expr *parse_primary(Parser *parser) {
    if (match(parser, TOK_INT)) {
        Expr *expr = new_expr(parser, EXPR_INT, parser->prev.line, parser->prev.col);
        expr->as.ival = parser->prev.ival;
        return expr;
    }
    if (match(parser, TOK_FLOAT)) {
        Expr *expr = new_expr(parser, EXPR_FLOAT, parser->prev.line, parser->prev.col);
        expr->as.fval = parser->prev.fval;
        return expr;
    }
    if (match(parser, TOK_STRING)) {
        Expr *expr = new_expr(parser, EXPR_STRING, parser->prev.line, parser->prev.col);
        expr->as.str.data = parser->prev.text;
        expr->as.str.len = parser->prev.text_len;
        return expr;
    }
    if (match(parser, TOK_TRUE) || match(parser, TOK_FALSE)) {
        Expr *expr = new_expr(parser, EXPR_BOOL, parser->prev.line, parser->prev.col);
        expr->as.bval = parser->prev.kind == TOK_TRUE;
        return expr;
    }
    if (match(parser, TOK_IDENT)) {
        Token name = parser->prev;
        if (!parser->cur.follows_newline && match(parser, TOK_LPAREN)) {
            Expr *expr = new_expr(parser, EXPR_CALL, name.line, name.col);
            expr->as.call.name = copy_token(parser, name);
            expr->as.call.func = -1;
            Expr **args = NULL;
            int nargs = 0;
            int cap = 0;
            if (!check(parser, TOK_RPAREN)) {
                for (;;) {
                    Expr *arg = parse_expr(parser);
                    DA_PUSH(parser->arena, args, nargs, cap, arg);
                    if (nargs > 64) {
                        error_at(parser, name, "too many arguments");
                        break;
                    }
                    if (!match(parser, TOK_COMMA)) {
                        break;
                    }
                    if (check(parser, TOK_RPAREN)) {
                        break;
                    }
                }
            }
            expect(parser, TOK_RPAREN, "')'");
            expr->as.call.args = args;
            expr->as.call.nargs = nargs;
            return expr;
        }
        Expr *expr = new_expr(parser, EXPR_VAR, name.line, name.col);
        expr->as.var.name = copy_token(parser, name);
        expr->as.var.slot = -1;
        return expr;
    }
    if (match(parser, TOK_LPAREN)) {
        Expr *expr = parse_expr(parser);
        expect(parser, TOK_RPAREN, "')'");
        return expr;
    }
    error_at(parser, parser->cur, "expected an expression");
    if (parser->cur.kind != TOK_EOF && parser->cur.kind != TOK_SEMI &&
        parser->cur.kind != TOK_RBRACE) {
        advance(parser);
    }
    return dummy_expr(parser);
}

static Expr *parse_unary(Parser *parser) {
    if (match(parser, TOK_MINUS) || match(parser, TOK_NOT)) {
        Token op = parser->prev;
        Expr *expr = new_expr(parser, EXPR_UNARY, op.line, op.col);
        expr->as.unary.op = op.kind == TOK_MINUS ? UN_NEG : UN_NOT;
        expr->as.unary.expr = parse_unary(parser);
        return expr;
    }
    return parse_primary(parser);
}

static BinOp binop_of(TokenKind kind) {
    switch (kind) {
    case TOK_PLUS: return BIN_ADD;
    case TOK_MINUS: return BIN_SUB;
    case TOK_STAR: return BIN_MUL;
    case TOK_SLASH: return BIN_DIV;
    case TOK_PERCENT: return BIN_MOD;
    case TOK_EQ: return BIN_EQ;
    case TOK_NE: return BIN_NE;
    case TOK_LT: return BIN_LT;
    case TOK_GT: return BIN_GT;
    case TOK_LE: return BIN_LE;
    case TOK_GE: return BIN_GE;
    case TOK_AND: return BIN_AND;
    case TOK_OR: return BIN_OR;
    default:
        return BIN_ADD;
    }
}

static Expr *make_binary(Parser *parser, BinOp op, Expr *left, Expr *right, Token op_tok) {
    Expr *expr = new_expr(parser, EXPR_BINARY, op_tok.line, op_tok.col);
    expr->as.binary.op = op;
    expr->as.binary.left = left;
    expr->as.binary.right = right;
    return expr;
}

static Expr *parse_factor(Parser *parser) {
    Expr *expr = parse_unary(parser);
    while (!parser->cur.follows_newline &&
           (check(parser, TOK_STAR) || check(parser, TOK_SLASH) || check(parser, TOK_PERCENT))) {
        advance(parser);
        Token op = parser->prev;
        BinOp bin = binop_of(op.kind);
        Expr *right = parse_unary(parser);
        expr = make_binary(parser, bin, expr, right, op);
    }
    return expr;
}

static Expr *parse_term(Parser *parser) {
    Expr *expr = parse_factor(parser);
    while (!parser->cur.follows_newline && (check(parser, TOK_PLUS) || check(parser, TOK_MINUS))) {
        advance(parser);
        Token op = parser->prev;
        BinOp bin = binop_of(op.kind);
        Expr *right = parse_factor(parser);
        expr = make_binary(parser, bin, expr, right, op);
    }
    return expr;
}

static Expr *parse_comparison(Parser *parser) {
    Expr *expr = parse_term(parser);
    while (!parser->cur.follows_newline &&
           (check(parser, TOK_LT) || check(parser, TOK_GT) || check(parser, TOK_LE) ||
            check(parser, TOK_GE))) {
        advance(parser);
        Token op = parser->prev;
        BinOp bin = binop_of(op.kind);
        Expr *right = parse_term(parser);
        expr = make_binary(parser, bin, expr, right, op);
    }
    return expr;
}

static Expr *parse_equality(Parser *parser) {
    Expr *expr = parse_comparison(parser);
    while (!parser->cur.follows_newline && (check(parser, TOK_EQ) || check(parser, TOK_NE))) {
        advance(parser);
        Token op = parser->prev;
        BinOp bin = binop_of(op.kind);
        Expr *right = parse_comparison(parser);
        expr = make_binary(parser, bin, expr, right, op);
    }
    return expr;
}

static Expr *parse_and(Parser *parser) {
    Expr *expr = parse_equality(parser);
    while (!parser->cur.follows_newline && match(parser, TOK_AND)) {
        Token op = parser->prev;
        Expr *right = parse_equality(parser);
        expr = make_binary(parser, BIN_AND, expr, right, op);
    }
    return expr;
}

static Expr *parse_expr(Parser *parser) {
    Expr *expr = parse_and(parser);
    while (!parser->cur.follows_newline && match(parser, TOK_OR)) {
        Token op = parser->prev;
        Expr *right = parse_and(parser);
        expr = make_binary(parser, BIN_OR, expr, right, op);
    }
    return expr;
}

static int starts_expr(TokenKind kind) {
    switch (kind) {
    case TOK_INT:
    case TOK_FLOAT:
    case TOK_STRING:
    case TOK_TRUE:
    case TOK_FALSE:
    case TOK_IDENT:
    case TOK_LPAREN:
    case TOK_MINUS:
    case TOK_NOT:
        return 1;
    default:
        return 0;
    }
}

static void sync_statement(Parser *parser) {
    parser->panic = 0;
    while (parser->cur.kind != TOK_EOF && parser->cur.kind != TOK_SEMI &&
           parser->cur.kind != TOK_RBRACE) {
        if (parser->cur.kind == TOK_FN || parser->cur.kind == TOK_LET ||
            parser->cur.kind == TOK_VAR || parser->cur.kind == TOK_IF ||
            parser->cur.kind == TOK_WHILE || parser->cur.kind == TOK_FOR ||
            parser->cur.kind == TOK_RETURN) {
            break;
        }
        advance(parser);
    }
    if (parser->cur.kind == TOK_SEMI) {
        advance(parser);
    }
}

static Stmt *parse_block(Parser *parser) {
    int line = parser->cur.line;
    int col = parser->cur.col;
    if (!match(parser, TOK_LBRACE)) {
        error_at(parser, parser->cur, "expected '{'");
        Stmt *empty = new_stmt(parser, STMT_BLOCK, line, col);
        return empty;
    }
    parser->panic = 0;
    Stmt *stmt = new_stmt(parser, STMT_BLOCK, line, col);
    Stmt **items = NULL;
    int count = 0;
    int cap = 0;
    while (!check(parser, TOK_RBRACE) && !check(parser, TOK_EOF)) {
        int before = parser->diag->errors;
        Stmt *item = parse_statement(parser);
        DA_PUSH(parser->arena, items, count, cap, item);
        if (parser->diag->errors > before) {
            sync_statement(parser);
        }
    }
    expect(parser, TOK_RBRACE, "'}'");
    parser->panic = 0;
    stmt->as.block.items = items;
    stmt->as.block.count = count;
    return stmt;
}

static Stmt *parse_if(Parser *parser) {
    Token keyword = parser->prev;
    Expr *cond = parse_expr(parser);
    Stmt *then_br = parse_block(parser);
    Stmt *else_br = NULL;
    if (match(parser, TOK_ELSE)) {
        if (match(parser, TOK_IF)) {
            else_br = parse_if(parser);
        } else {
            else_br = parse_block(parser);
        }
    }
    Stmt *stmt = new_stmt(parser, STMT_IF, keyword.line, keyword.col);
    stmt->as.ifs.cond = cond;
    stmt->as.ifs.then_br = then_br;
    stmt->as.ifs.else_br = else_br;
    return stmt;
}

static Stmt *parse_statement(Parser *parser) {
    if (match(parser, TOK_SEMI)) {
        return new_stmt(parser, STMT_BLOCK, parser->prev.line, parser->prev.col);
    }
    if (match(parser, TOK_LET) || match(parser, TOK_VAR)) {
        int mutable = parser->prev.kind == TOK_VAR;
        Token keyword = parser->prev;
        if (!match(parser, TOK_IDENT)) {
            error_at(parser, parser->cur, "expected a variable name");
            return new_stmt(parser, STMT_BLOCK, keyword.line, keyword.col);
        }
        Token name = parser->prev;
        Type type;
        type.kind = TYPE_NONE;
        int has_type = 0;
        if (match(parser, TOK_COLON)) {
            type = parse_type(parser);
            has_type = 1;
        }
        expect(parser, TOK_ASSIGN, "'='");
        Expr *init = parse_expr(parser);
        expect_stmt_end(parser);
        Stmt *stmt = new_stmt(parser, STMT_LET, keyword.line, keyword.col);
        stmt->as.let.name = copy_token(parser, name);
        stmt->as.let.type = type;
        stmt->as.let.mutable = mutable;
        stmt->as.let.init = init;
        stmt->as.let.slot = -1;
        (void)has_type;
        if (!has_type) {
            stmt->as.let.type.kind = TYPE_NONE;
        }
        return stmt;
    }
    if (match(parser, TOK_IF)) {
        return parse_if(parser);
    }
    if (match(parser, TOK_WHILE)) {
        Token keyword = parser->prev;
        Expr *cond = parse_expr(parser);
        Stmt *body = parse_block(parser);
        Stmt *stmt = new_stmt(parser, STMT_WHILE, keyword.line, keyword.col);
        stmt->as.whiles.cond = cond;
        stmt->as.whiles.body = body;
        return stmt;
    }
    if (match(parser, TOK_FOR)) {
        Token keyword = parser->prev;
        if (!match(parser, TOK_IDENT)) {
            error_at(parser, parser->cur, "expected a loop variable name");
            return new_stmt(parser, STMT_BLOCK, keyword.line, keyword.col);
        }
        Token name = parser->prev;
        expect(parser, TOK_IN, "'in'");
        Expr *start = parse_expr(parser);
        expect(parser, TOK_DOTDOT, "'..'");
        Expr *end = parse_expr(parser);
        Stmt *body = parse_block(parser);
        Stmt *stmt = new_stmt(parser, STMT_FOR, keyword.line, keyword.col);
        stmt->as.fors.name = copy_token(parser, name);
        stmt->as.fors.start = start;
        stmt->as.fors.end = end;
        stmt->as.fors.body = body;
        stmt->as.fors.slot = -1;
        stmt->as.fors.end_slot = -1;
        return stmt;
    }
    if (match(parser, TOK_RETURN)) {
        Token keyword = parser->prev;
        Expr *value = NULL;
        if (!at_stmt_end(parser)) {
            value = parse_expr(parser);
        }
        expect_stmt_end(parser);
        Stmt *stmt = new_stmt(parser, STMT_RETURN, keyword.line, keyword.col);
        stmt->as.ret.value = value;
        return stmt;
    }
    if (check(parser, TOK_LBRACE)) {
        return parse_block(parser);
    }
    if (check(parser, TOK_IDENT) && parser->next.kind == TOK_ASSIGN) {
        Token name = parser->cur;
        advance(parser);
        advance(parser);
        Expr *value = parse_expr(parser);
        expect_stmt_end(parser);
        Stmt *stmt = new_stmt(parser, STMT_ASSIGN, name.line, name.col);
        stmt->as.assign.name = copy_token(parser, name);
        stmt->as.assign.value = value;
        stmt->as.assign.slot = -1;
        stmt->as.assign.type.kind = TYPE_NONE;
        return stmt;
    }
    if (starts_expr(parser->cur.kind)) {
        int line = parser->cur.line;
        int col = parser->cur.col;
        Expr *expr = parse_expr(parser);
        expect_stmt_end(parser);
        Stmt *stmt = new_stmt(parser, STMT_EXPR, line, col);
        stmt->as.expr = expr;
        return stmt;
    }
    error_at(parser, parser->cur, "expected a statement");
    if (parser->cur.kind != TOK_EOF && parser->cur.kind != TOK_RBRACE) {
        advance(parser);
    }
    return new_stmt(parser, STMT_BLOCK, parser->cur.line, parser->cur.col);
}

static void parse_function(Parser *parser) {
    Token keyword = parser->prev;
    if (!match(parser, TOK_IDENT)) {
        error_at(parser, parser->cur, "expected a function name");
        return;
    }
    Token name = parser->prev;
    expect(parser, TOK_LPAREN, "'('");
    Param *params = NULL;
    int nparams = 0;
    int cap = 0;
    if (!check(parser, TOK_RPAREN)) {
        for (;;) {
            if (!match(parser, TOK_IDENT)) {
                error_at(parser, parser->cur, "expected a parameter name");
                break;
            }
            Token pname = parser->prev;
            expect(parser, TOK_COLON, "':'");
            Type ptype = parse_type(parser);
            Param param;
            memset(&param, 0, sizeof(param));
            param.name = copy_token(parser, pname);
            param.type = ptype;
            param.slot = nparams;
            DA_PUSH(parser->arena, params, nparams, cap, param);
            if (nparams > 64) {
                error_at(parser, pname, "too many parameters");
                break;
            }
            if (!match(parser, TOK_COMMA)) {
                break;
            }
            if (check(parser, TOK_RPAREN)) {
                break;
            }
        }
    }
    expect(parser, TOK_RPAREN, "')'");
    Type ret;
    ret.kind = TYPE_VOID;
    if (match(parser, TOK_ARROW)) {
        ret = parse_type(parser);
    }
    Stmt *body = parse_block(parser);
    Function fn;
    memset(&fn, 0, sizeof(fn));
    fn.name = copy_token(parser, name);
    fn.ret = ret;
    fn.params = params;
    fn.nparams = nparams;
    fn.body = body;
    fn.line = keyword.line;
    fn.col = keyword.col;
    for (int i = 0; i < parser->nfuncs; i++) {
        if (strcmp(parser->funcs[i].name, fn.name) == 0) {
            diag_error(parser->diag, name.line, name.col, "function '%s' is already defined", fn.name);
        }
    }
    DA_PUSH(parser->arena, parser->funcs, parser->nfuncs, parser->capfuncs, fn);
}

Parsed parse_source(const char *file, const char *src, int length, Arena *arena, Diag *diag) {
    Parser parser;
    memset(&parser, 0, sizeof(parser));
    parser.arena = arena;
    parser.diag = diag;
    lexer_init(&parser.lexer, src, length, arena, diag);
    parser.cur = lexer_next(&parser.lexer);
    parser.next = lexer_next(&parser.lexer);
    (void)file;
    while (!check(&parser, TOK_EOF)) {
        if (match(&parser, TOK_FN)) {
            parser.panic = 0;
            parse_function(&parser);
            continue;
        }
        error_at(&parser, parser.cur, "expected a function ('fn')");
        if (parser.cur.kind == TOK_EOF) {
            break;
        }
        advance(&parser);
        while (!check(&parser, TOK_EOF) && !check(&parser, TOK_FN)) {
            advance(&parser);
        }
        parser.panic = 0;
    }
    Parsed parsed;
    parsed.funcs = parser.funcs;
    parsed.nfuncs = parser.nfuncs;
    return parsed;
}
