#ifndef SELDUN_CODEGEN_H
#define SELDUN_CODEGEN_H

#include "ast.h"
#include "program.h"

Program *codegen_compile(Parsed *parsed, Diag *diag);

#endif
