#ifndef SELDUN_LEXER_H
#define SELDUN_LEXER_H

#include "common.h"

typedef enum TokenKind {
    TOK_EOF = 0,
    TOK_IDENT,
    TOK_INT,
    TOK_FLOAT,
    TOK_STRING,
    TOK_FN,
    TOK_LET,
    TOK_VAR,
    TOK_IF,
    TOK_ELSE,
    TOK_WHILE,
    TOK_FOR,
    TOK_IN,
    TOK_RETURN,
    TOK_TRUE,
    TOK_FALSE,
    TOK_INT_T,
    TOK_FLOAT_T,
    TOK_BOOL_T,
    TOK_STRING_T,
    TOK_VOID_T,
    TOK_PLUS,
    TOK_MINUS,
    TOK_STAR,
    TOK_SLASH,
    TOK_PERCENT,
    TOK_EQ,
    TOK_NE,
    TOK_LT,
    TOK_GT,
    TOK_LE,
    TOK_GE,
    TOK_AND,
    TOK_OR,
    TOK_NOT,
    TOK_ASSIGN,
    TOK_ARROW,
    TOK_LPAREN,
    TOK_RPAREN,
    TOK_LBRACE,
    TOK_RBRACE,
    TOK_COMMA,
    TOK_COLON,
    TOK_SEMI,
    TOK_DOTDOT
} TokenKind;

typedef struct Token {
    TokenKind kind;
    int line;
    int col;
    const char *lexeme;
    int lexeme_len;
    int64_t ival;
    double fval;
    const char *text;
    int text_len;
    int follows_newline;
} Token;

typedef struct Lexer {
    const char *src;
    int length;
    int pos;
    int line;
    int col;
    Arena *arena;
    Diag *diag;
    int pending_nl;
} Lexer;

void lexer_init(Lexer *lexer, const char *src, int length, Arena *arena, Diag *diag);
Token lexer_next(Lexer *lexer);

#endif
