#include "codegen.h"

#include "sema.h"

typedef struct Compiler {
    Diag *diag;
    Parsed *parsed;
    Program *program;
    int const_cap;
} Compiler;

typedef struct Gen {
    Compiler *compiler;
    Function *fn;
    uint8_t *code;
    int *lines;
    int len;
    int cap;
    int line;
} Gen;

static void emit_byte(Gen *gen, uint8_t byte) {
    if (gen->len >= gen->cap) {
        int cap = gen->cap < 64 ? 64 : gen->cap * 2;
        uint8_t *code = (uint8_t *)realloc(gen->code, (size_t)cap);
        int *lines = (int *)realloc(gen->lines, (size_t)cap * sizeof(int));
        if (code == NULL || lines == NULL) {
            fprintf(stderr, "out of memory\n");
            exit(1);
        }
        gen->code = code;
        gen->lines = lines;
        gen->cap = cap;
    }
    gen->lines[gen->len] = gen->line;
    gen->code[gen->len++] = byte;
}

static void emit_op(Gen *gen, uint8_t op) {
    emit_byte(gen, op);
}

static void emit_u16(Gen *gen, int value) {
    emit_byte(gen, (uint8_t)(value & 0xff));
    emit_byte(gen, (uint8_t)((value >> 8) & 0xff));
}

static void emit_i32(Gen *gen, int32_t value) {
    uint32_t bits = (uint32_t)value;
    emit_byte(gen, (uint8_t)(bits & 0xff));
    emit_byte(gen, (uint8_t)((bits >> 8) & 0xff));
    emit_byte(gen, (uint8_t)((bits >> 16) & 0xff));
    emit_byte(gen, (uint8_t)((bits >> 24) & 0xff));
}

static int emit_jump(Gen *gen, uint8_t op) {
    emit_op(gen, op);
    int patch = gen->len;
    emit_i32(gen, 0);
    return patch;
}

static void patch_jump(Gen *gen, int patch) {
    int32_t rel = (int32_t)(gen->len - (patch + 4));
    uint32_t bits = (uint32_t)rel;
    gen->code[patch] = (uint8_t)(bits & 0xff);
    gen->code[patch + 1] = (uint8_t)((bits >> 8) & 0xff);
    gen->code[patch + 2] = (uint8_t)((bits >> 16) & 0xff);
    gen->code[patch + 3] = (uint8_t)((bits >> 24) & 0xff);
}

static void emit_loop(Gen *gen, int target) {
    emit_op(gen, OP_JUMP);
    int patch = gen->len;
    int32_t rel = (int32_t)(target - (patch + 4));
    emit_i32(gen, rel);
}

static int add_const(Gen *gen, Value value) {
    Program *program = gen->compiler->program;
    for (int i = 0; i < program->nconst; i++) {
        Value existing = program->consts[i];
        if (existing.kind != value.kind) {
            continue;
        }
        if (value.kind == VAL_INT && existing.i == value.i) {
            return i;
        }
        if (value.kind == VAL_FLOAT && existing.f == value.f) {
            return i;
        }
        if (value.kind == VAL_BOOL && existing.b == value.b) {
            return i;
        }
        if (value.kind == VAL_STR && existing.slen == value.slen &&
            (value.slen == 0 || memcmp(existing.s, value.s, (size_t)value.slen) == 0)) {
            return i;
        }
    }
    if (program->nconst >= 65535) {
        diag_error(gen->compiler->diag, gen->line, 1, "too many constants");
        return 0;
    }
    if (program->nconst >= gen->compiler->const_cap) {
        int cap = gen->compiler->const_cap < 16 ? 16 : gen->compiler->const_cap * 2;
        Value *consts = (Value *)realloc(program->consts, (size_t)cap * sizeof(Value));
        if (consts == NULL) {
            fprintf(stderr, "out of memory\n");
            exit(1);
        }
        program->consts = consts;
        gen->compiler->const_cap = cap;
    }
    program->consts[program->nconst] = value;
    return program->nconst++;
}

static void emit_const(Gen *gen, Value value) {
    int index = add_const(gen, value);
    emit_op(gen, OP_CONST);
    emit_u16(gen, index);
}

static void gen_expr(Gen *gen, Expr *expr);

static void promote_to_float(Gen *gen, Type actual, Type expected) {
    if (expected.kind == TYPE_FLOAT && actual.kind == TYPE_INT) {
        emit_op(gen, OP_I2F);
    }
}

static uint8_t int_arith(BinOp op) {
    switch (op) {
    case BIN_ADD: return OP_ADD_I;
    case BIN_SUB: return OP_SUB_I;
    case BIN_MUL: return OP_MUL_I;
    case BIN_DIV: return OP_DIV_I;
    case BIN_MOD: return OP_MOD_I;
    default: return OP_ADD_I;
    }
}

static uint8_t float_arith(BinOp op) {
    switch (op) {
    case BIN_ADD: return OP_ADD_F;
    case BIN_SUB: return OP_SUB_F;
    case BIN_MUL: return OP_MUL_F;
    case BIN_DIV: return OP_DIV_F;
    default: return OP_ADD_F;
    }
}

static uint8_t int_cmp(BinOp op) {
    switch (op) {
    case BIN_EQ: return OP_EQ_I;
    case BIN_NE: return OP_NE_I;
    case BIN_LT: return OP_LT_I;
    case BIN_GT: return OP_GT_I;
    case BIN_LE: return OP_LE_I;
    case BIN_GE: return OP_GE_I;
    default: return OP_EQ_I;
    }
}

static uint8_t float_cmp(BinOp op) {
    switch (op) {
    case BIN_EQ: return OP_EQ_F;
    case BIN_NE: return OP_NE_F;
    case BIN_LT: return OP_LT_F;
    case BIN_GT: return OP_GT_F;
    case BIN_LE: return OP_LE_F;
    case BIN_GE: return OP_GE_F;
    default: return OP_EQ_F;
    }
}

static void gen_expr(Gen *gen, Expr *expr) {
    gen->line = expr->line;
    switch (expr->kind) {
    case EXPR_INT: {
        Value value;
        memset(&value, 0, sizeof(value));
        value.kind = VAL_INT;
        value.i = expr->as.ival;
        emit_const(gen, value);
        break;
    }
    case EXPR_FLOAT: {
        Value value;
        memset(&value, 0, sizeof(value));
        value.kind = VAL_FLOAT;
        value.f = expr->as.fval;
        emit_const(gen, value);
        break;
    }
    case EXPR_BOOL:
        emit_op(gen, expr->as.bval ? OP_TRUE : OP_FALSE);
        break;
    case EXPR_STRING: {
        Value value;
        memset(&value, 0, sizeof(value));
        value.kind = VAL_STR;
        value.s = expr->as.str.data != NULL ? expr->as.str.data : "";
        value.slen = expr->as.str.len;
        emit_const(gen, value);
        break;
    }
    case EXPR_VAR:
        emit_op(gen, OP_LOAD);
        emit_u16(gen, expr->as.var.slot);
        break;
    case EXPR_UNARY:
        gen_expr(gen, expr->as.unary.expr);
        gen->line = expr->line;
        if (expr->as.unary.op == UN_NOT) {
            emit_op(gen, OP_NOT);
        } else if (expr->type.kind == TYPE_FLOAT) {
            emit_op(gen, OP_NEG_F);
        } else {
            emit_op(gen, OP_NEG_I);
        }
        break;
    case EXPR_BINARY: {
        BinOp op = expr->as.binary.op;
        if (op == BIN_AND) {
            gen_expr(gen, expr->as.binary.left);
            gen->line = expr->line;
            emit_op(gen, OP_DUP);
            int jump = emit_jump(gen, OP_JUMP_IF_FALSE);
            emit_op(gen, OP_POP);
            gen_expr(gen, expr->as.binary.right);
            patch_jump(gen, jump);
            break;
        }
        if (op == BIN_OR) {
            gen_expr(gen, expr->as.binary.left);
            gen->line = expr->line;
            emit_op(gen, OP_DUP);
            int jump = emit_jump(gen, OP_JUMP_IF_TRUE);
            emit_op(gen, OP_POP);
            gen_expr(gen, expr->as.binary.right);
            patch_jump(gen, jump);
            break;
        }
        TypeKind lk = expr->as.binary.left->type.kind;
        TypeKind rk = expr->as.binary.right->type.kind;
        int numeric = (lk == TYPE_INT || lk == TYPE_FLOAT) && (rk == TYPE_INT || rk == TYPE_FLOAT);
        int promote = numeric && (lk == TYPE_FLOAT || rk == TYPE_FLOAT);
        gen_expr(gen, expr->as.binary.left);
        if (promote && lk == TYPE_INT) {
            emit_op(gen, OP_I2F);
        }
        gen_expr(gen, expr->as.binary.right);
        if (promote && rk == TYPE_INT) {
            emit_op(gen, OP_I2F);
        }
        gen->line = expr->line;
        if (lk == TYPE_STRING || rk == TYPE_STRING) {
            if (op == BIN_ADD) {
                emit_op(gen, OP_CONCAT);
            } else if (op == BIN_EQ) {
                emit_op(gen, OP_EQ_S);
            } else {
                emit_op(gen, OP_NE_S);
            }
        } else if (lk == TYPE_BOOL || rk == TYPE_BOOL) {
            emit_op(gen, op == BIN_EQ ? OP_EQ_B : OP_NE_B);
        } else if (op == BIN_EQ || op == BIN_NE || op == BIN_LT || op == BIN_GT || op == BIN_LE ||
                   op == BIN_GE) {
            emit_op(gen, promote ? float_cmp(op) : int_cmp(op));
        } else {
            emit_op(gen, promote ? float_arith(op) : int_arith(op));
        }
        break;
    }
    case EXPR_CALL:
        if (expr->as.call.func >= 0) {
            Function *callee = &gen->compiler->parsed->funcs[expr->as.call.func];
            int n = expr->as.call.nargs;
            if (n > callee->nparams) {
                n = callee->nparams;
            }
            for (int i = 0; i < n; i++) {
                gen_expr(gen, expr->as.call.args[i]);
                promote_to_float(gen, expr->as.call.args[i]->type, callee->params[i].type);
            }
            gen->line = expr->line;
            emit_op(gen, OP_CALL);
            emit_u16(gen, expr->as.call.func);
            emit_byte(gen, (uint8_t)n);
        } else {
            if (expr->as.call.nargs >= 1) {
                gen_expr(gen, expr->as.call.args[0]);
            }
            gen->line = expr->line;
            if (expr->as.call.builtin == BUILTIN_PRINT) {
                emit_op(gen, OP_PRINT);
            } else if (expr->as.call.builtin == BUILTIN_PRINTLN) {
                emit_op(gen, OP_PRINTLN);
            } else if (expr->as.call.builtin == BUILTIN_LEN) {
                emit_op(gen, OP_LEN);
            } else if (expr->as.call.builtin == BUILTIN_STR) {
                emit_op(gen, OP_STR);
            } else {
                emit_op(gen, OP_NIL);
            }
        }
        break;
    default:
        emit_op(gen, OP_NIL);
        break;
    }
}

static void gen_stmt(Gen *gen, Stmt *stmt) {
    if (stmt == NULL) {
        return;
    }
    gen->line = stmt->line;
    switch (stmt->kind) {
    case STMT_BLOCK:
        for (int i = 0; i < stmt->as.block.count; i++) {
            gen_stmt(gen, stmt->as.block.items[i]);
        }
        break;
    case STMT_LET:
        gen_expr(gen, stmt->as.let.init);
        promote_to_float(gen, stmt->as.let.init->type, stmt->as.let.type);
        gen->line = stmt->line;
        emit_op(gen, OP_STORE);
        emit_u16(gen, stmt->as.let.slot);
        break;
    case STMT_ASSIGN:
        gen_expr(gen, stmt->as.assign.value);
        promote_to_float(gen, stmt->as.assign.value->type, stmt->as.assign.type);
        gen->line = stmt->line;
        emit_op(gen, OP_STORE);
        emit_u16(gen, stmt->as.assign.slot);
        break;
    case STMT_EXPR:
        gen_expr(gen, stmt->as.expr);
        emit_op(gen, OP_POP);
        break;
    case STMT_IF: {
        gen_expr(gen, stmt->as.ifs.cond);
        int else_jump = emit_jump(gen, OP_JUMP_IF_FALSE);
        gen_stmt(gen, stmt->as.ifs.then_br);
        if (stmt->as.ifs.else_br != NULL) {
            int end_jump = emit_jump(gen, OP_JUMP);
            patch_jump(gen, else_jump);
            gen_stmt(gen, stmt->as.ifs.else_br);
            patch_jump(gen, end_jump);
        } else {
            patch_jump(gen, else_jump);
        }
        break;
    }
    case STMT_WHILE: {
        int start = gen->len;
        gen_expr(gen, stmt->as.whiles.cond);
        int end_jump = emit_jump(gen, OP_JUMP_IF_FALSE);
        gen_stmt(gen, stmt->as.whiles.body);
        emit_loop(gen, start);
        patch_jump(gen, end_jump);
        break;
    }
    case STMT_FOR: {
        gen_expr(gen, stmt->as.fors.start);
        gen->line = stmt->line;
        emit_op(gen, OP_STORE);
        emit_u16(gen, stmt->as.fors.slot);
        gen_expr(gen, stmt->as.fors.end);
        gen->line = stmt->line;
        emit_op(gen, OP_STORE);
        emit_u16(gen, stmt->as.fors.end_slot);
        int loop = gen->len;
        emit_op(gen, OP_LOAD);
        emit_u16(gen, stmt->as.fors.slot);
        emit_op(gen, OP_LOAD);
        emit_u16(gen, stmt->as.fors.end_slot);
        emit_op(gen, OP_LT_I);
        int end_jump = emit_jump(gen, OP_JUMP_IF_FALSE);
        gen_stmt(gen, stmt->as.fors.body);
        gen->line = stmt->line;
        emit_op(gen, OP_LOAD);
        emit_u16(gen, stmt->as.fors.slot);
        {
            Value one;
            memset(&one, 0, sizeof(one));
            one.kind = VAL_INT;
            one.i = 1;
            emit_const(gen, one);
        }
        emit_op(gen, OP_ADD_I);
        emit_op(gen, OP_STORE);
        emit_u16(gen, stmt->as.fors.slot);
        emit_loop(gen, loop);
        patch_jump(gen, end_jump);
        break;
    }
    case STMT_RETURN:
        if (stmt->as.ret.value != NULL) {
            gen_expr(gen, stmt->as.ret.value);
            promote_to_float(gen, stmt->as.ret.value->type, gen->fn->ret);
        } else {
            emit_op(gen, OP_NIL);
        }
        gen->line = stmt->line;
        emit_op(gen, OP_RETURN);
        break;
    default:
        break;
    }
}

static void compile_function(Compiler *compiler, Function *fn, CompiledFn *out) {
    Gen gen;
    memset(&gen, 0, sizeof(gen));
    gen.compiler = compiler;
    gen.fn = fn;
    gen.line = fn->line;
    gen_stmt(&gen, fn->body);
    gen.line = fn->line;
    emit_op(&gen, OP_NIL);
    emit_op(&gen, OP_RETURN);
    out->name = fn->name;
    out->nlocals = fn->nlocals;
    out->nparams = fn->nparams;
    out->code = gen.code;
    out->lines = gen.lines;
    out->code_len = gen.len;
}

Program *codegen_compile(Parsed *parsed, Diag *diag) {
    Program *program = (Program *)calloc(1, sizeof(Program));
    if (program == NULL) {
        fprintf(stderr, "out of memory\n");
        exit(1);
    }
    program->main_index = -1;
    program->nfn = parsed->nfuncs;
    if (parsed->nfuncs > 0) {
        program->fns = (CompiledFn *)calloc((size_t)parsed->nfuncs, sizeof(CompiledFn));
        if (program->fns == NULL) {
            fprintf(stderr, "out of memory\n");
            exit(1);
        }
    }
    Compiler compiler;
    memset(&compiler, 0, sizeof(compiler));
    compiler.diag = diag;
    compiler.parsed = parsed;
    compiler.program = program;
    for (int i = 0; i < parsed->nfuncs; i++) {
        compile_function(&compiler, &parsed->funcs[i], &program->fns[i]);
        if (strcmp(parsed->funcs[i].name, "main") == 0) {
            program->main_index = i;
        }
    }
    return program;
}

void program_free(Program *program) {
    if (program == NULL) {
        return;
    }
    for (int i = 0; i < program->nfn; i++) {
        free(program->fns[i].code);
        free(program->fns[i].lines);
    }
    free(program->fns);
    free(program->consts);
    free(program);
}

static int32_t read_i32_at(const uint8_t *code) {
    uint32_t bits = (uint32_t)code[0] | ((uint32_t)code[1] << 8) | ((uint32_t)code[2] << 16) |
                    ((uint32_t)code[3] << 24);
    return (int32_t)bits;
}

static const char *op_name(uint8_t op) {
    switch (op) {
    case OP_NIL: return "NIL";
    case OP_TRUE: return "TRUE";
    case OP_FALSE: return "FALSE";
    case OP_CONST: return "CONST";
    case OP_LOAD: return "LOAD";
    case OP_STORE: return "STORE";
    case OP_POP: return "POP";
    case OP_DUP: return "DUP";
    case OP_ADD_I: return "ADD_I";
    case OP_SUB_I: return "SUB_I";
    case OP_MUL_I: return "MUL_I";
    case OP_DIV_I: return "DIV_I";
    case OP_MOD_I: return "MOD_I";
    case OP_NEG_I: return "NEG_I";
    case OP_ADD_F: return "ADD_F";
    case OP_SUB_F: return "SUB_F";
    case OP_MUL_F: return "MUL_F";
    case OP_DIV_F: return "DIV_F";
    case OP_NEG_F: return "NEG_F";
    case OP_I2F: return "I2F";
    case OP_EQ_I: return "EQ_I";
    case OP_NE_I: return "NE_I";
    case OP_LT_I: return "LT_I";
    case OP_GT_I: return "GT_I";
    case OP_LE_I: return "LE_I";
    case OP_GE_I: return "GE_I";
    case OP_EQ_F: return "EQ_F";
    case OP_NE_F: return "NE_F";
    case OP_LT_F: return "LT_F";
    case OP_GT_F: return "GT_F";
    case OP_LE_F: return "LE_F";
    case OP_GE_F: return "GE_F";
    case OP_EQ_S: return "EQ_S";
    case OP_NE_S: return "NE_S";
    case OP_EQ_B: return "EQ_B";
    case OP_NE_B: return "NE_B";
    case OP_NOT: return "NOT";
    case OP_CONCAT: return "CONCAT";
    case OP_JUMP: return "JUMP";
    case OP_JUMP_IF_FALSE: return "JUMP_IF_FALSE";
    case OP_JUMP_IF_TRUE: return "JUMP_IF_TRUE";
    case OP_CALL: return "CALL";
    case OP_PRINT: return "PRINT";
    case OP_PRINTLN: return "PRINTLN";
    case OP_LEN: return "LEN";
    case OP_STR: return "STR";
    case OP_RETURN: return "RETURN";
    default: return "???";
    }
}

static void dump_value(FILE *out, Value value) {
    switch (value.kind) {
    case VAL_INT:
        fprintf(out, "%" PRId64, value.i);
        break;
    case VAL_FLOAT:
        fprintf(out, "%.15g", value.f);
        break;
    case VAL_BOOL:
        fputs(value.b ? "true" : "false", out);
        break;
    case VAL_STR:
        fputc('"', out);
        for (int i = 0; i < value.slen; i++) {
            char c = value.s[i];
            if (c == '"' || c == '\\') {
                fprintf(out, "\\%c", c);
            } else if (c == '\n') {
                fputs("\\n", out);
            } else {
                fputc(c, out);
            }
        }
        fputc('"', out);
        break;
    default:
        fputs("nil", out);
        break;
    }
}

static int dump_insn(const Program *program, const CompiledFn *fn, int ip, FILE *out) {
    if (ip >= fn->code_len) {
        return 1;
    }
    uint8_t op = fn->code[ip];
    fprintf(out, "  %04d  %s", ip, op_name(op));
    int width = 1;
    if (op == OP_CONST || op == OP_LOAD || op == OP_STORE) {
        if (ip + 2 < fn->code_len) {
            int index = fn->code[ip + 1] | (fn->code[ip + 2] << 8);
            fprintf(out, " %d", index);
            if (op == OP_CONST && index >= 0 && index < program->nconst) {
                fputs("  ; ", out);
                dump_value(out, program->consts[index]);
            }
        }
        width = 3;
    } else if (op == OP_JUMP || op == OP_JUMP_IF_FALSE || op == OP_JUMP_IF_TRUE) {
        if (ip + 4 < fn->code_len) {
            int32_t rel = read_i32_at(fn->code + ip + 1);
            fprintf(out, " -> %d", ip + 5 + rel);
        }
        width = 5;
    } else if (op == OP_CALL) {
        if (ip + 3 < fn->code_len) {
            int index = fn->code[ip + 1] | (fn->code[ip + 2] << 8);
            int argc = fn->code[ip + 3];
            const char *name = (index >= 0 && index < program->nfn) ? program->fns[index].name : "?";
            fprintf(out, " %s (%d args)", name, argc);
        }
        width = 4;
    }
    fputc('\n', out);
    return width;
}

void program_dump(const Program *program, FILE *out) {
    fprintf(out, "constants: %d\n", program->nconst);
    for (int i = 0; i < program->nconst; i++) {
        fprintf(out, "  %d  ", i);
        dump_value(out, program->consts[i]);
        fputc('\n', out);
    }
    for (int i = 0; i < program->nfn; i++) {
        const CompiledFn *fn = &program->fns[i];
        fprintf(out, "fn %s  params=%d locals=%d%s\n", fn->name, fn->nparams, fn->nlocals,
                i == program->main_index ? "  entry" : "");
        int ip = 0;
        while (ip < fn->code_len) {
            ip += dump_insn(program, fn, ip, out);
        }
    }
}
