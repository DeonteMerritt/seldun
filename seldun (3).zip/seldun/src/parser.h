#ifndef SELDUN_PARSER_H
#define SELDUN_PARSER_H

#include "ast.h"
#include "lexer.h"

Parsed parse_source(const char *file, const char *src, int length, Arena *arena, Diag *diag);

#endif
