#ifndef SELDUN_SEMA_H
#define SELDUN_SEMA_H

#include "ast.h"

enum {
    BUILTIN_NONE = 0,
    BUILTIN_PRINT = 1,
    BUILTIN_PRINTLN = 2,
    BUILTIN_LEN = 3,
    BUILTIN_STR = 4
};

int sema_check(Parsed *parsed, Arena *arena, Diag *diag);

#endif
