#include "vm.h"

#include <limits.h>

#define STACK_MAX 8192
#define FRAME_MAX 1024

typedef struct Frame {
    CompiledFn *fn;
    int ip;
    Value *slots;
} Frame;

typedef struct Vm {
    Program *program;
    const char *file;
    Value stack[STACK_MAX];
    int sp;
    Frame frames[FRAME_MAX];
    int frame_count;
    Arena arena;
    int failed;
    int halted;
    Value result;
    char err[256];
    int err_line;
    const char *err_fn;
} Vm;

static void vm_fail(Vm *vm, const char *msg) {
    if (vm->failed) {
        return;
    }
    vm->failed = 1;
    snprintf(vm->err, sizeof(vm->err), "%s", msg);
}

static int push(Vm *vm, Value value) {
    if (vm->failed) {
        return 0;
    }
    if (vm->sp >= STACK_MAX) {
        vm_fail(vm, "stack overflow");
        return 0;
    }
    vm->stack[vm->sp++] = value;
    return 1;
}

static int pop(Vm *vm, Value *out) {
    if (vm->failed) {
        return 0;
    }
    if (vm->sp <= 0) {
        vm_fail(vm, "stack underflow");
        return 0;
    }
    *out = vm->stack[--vm->sp];
    return 1;
}

static int read_operand(Vm *vm, Frame *frame, int width) {
    if (frame->ip + width > frame->fn->code_len) {
        vm_fail(vm, "truncated instruction");
        return 0;
    }
    return 1;
}

static int read_u16(Frame *frame) {
    int value = frame->fn->code[frame->ip] | (frame->fn->code[frame->ip + 1] << 8);
    frame->ip += 2;
    return value;
}

static int32_t read_i32(Frame *frame) {
    const uint8_t *bytes = frame->fn->code + frame->ip;
    uint32_t bits = (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8) | ((uint32_t)bytes[2] << 16) |
                    ((uint32_t)bytes[3] << 24);
    frame->ip += 4;
    return (int32_t)bits;
}

static void print_value(FILE *out, Value value) {
    switch (value.kind) {
    case VAL_INT:
        fprintf(out, "%" PRId64, value.i);
        break;
    case VAL_FLOAT: {
        char buf[64];
        snprintf(buf, sizeof(buf), "%.15g", value.f);
        fputs(buf, out);
        break;
    }
    case VAL_BOOL:
        fputs(value.b ? "true" : "false", out);
        break;
    case VAL_STR:
        if (value.slen > 0 && value.s != NULL) {
            fwrite(value.s, 1, (size_t)value.slen, out);
        }
        break;
    default:
        fputs("nil", out);
        break;
    }
}

static int values_equal(Value left, Value right) {
    if (left.kind != right.kind) {
        return 0;
    }
    switch (left.kind) {
    case VAL_INT:
        return left.i == right.i;
    case VAL_FLOAT:
        return left.f == right.f;
    case VAL_BOOL:
        return left.b == right.b;
    case VAL_STR:
        return left.slen == right.slen &&
               (left.slen == 0 || memcmp(left.s, right.s, (size_t)left.slen) == 0);
    default:
        return 1;
    }
}

static Value make_bool(int value) {
    Value out;
    memset(&out, 0, sizeof(out));
    out.kind = VAL_BOOL;
    out.b = value ? 1 : 0;
    return out;
}

static Value make_int(int64_t value) {
    Value out;
    memset(&out, 0, sizeof(out));
    out.kind = VAL_INT;
    out.i = value;
    return out;
}

static Value make_float(double value) {
    Value out;
    memset(&out, 0, sizeof(out));
    out.kind = VAL_FLOAT;
    out.f = value;
    return out;
}

static char *vm_copy(Vm *vm, const char *text, int len) {
    char *copy = (char *)arena_alloc(&vm->arena, (size_t)len + 1);
    if (len > 0 && text != NULL) {
        memcpy(copy, text, (size_t)len);
    }
    copy[len] = '\0';
    return copy;
}

static int div_overflow(int64_t left, int64_t right) {
    return left == INT64_MIN && right == -1;
}

int vm_run(Program *program, const char *file) {
    if (program == NULL || program->main_index < 0 || program->main_index >= program->nfn) {
        fprintf(stderr, "runtime error: %s: missing main\n", file != NULL ? file : "<input>");
        return 1;
    }
    Vm *vm = (Vm *)calloc(1, sizeof(Vm));
    if (vm == NULL) {
        fprintf(stderr, "out of memory\n");
        return 1;
    }
    vm->program = program;
    vm->file = file;
    vm->err_fn = "main";

    CompiledFn *entry = &program->fns[program->main_index];
    Frame *first = &vm->frames[0];
    first->fn = entry;
    first->ip = 0;
    if (entry->nlocals > 0) {
        first->slots = (Value *)calloc((size_t)entry->nlocals, sizeof(Value));
        if (first->slots == NULL) {
            fprintf(stderr, "out of memory\n");
            free(vm);
            return 1;
        }
    }
    vm->frame_count = 1;

    while (!vm->failed && !vm->halted) {
        Frame *frame = &vm->frames[vm->frame_count - 1];
        if (frame->ip < 0 || frame->ip >= frame->fn->code_len) {
            vm->err_line = 0;
            vm->err_fn = frame->fn->name;
            vm_fail(vm, "ran off the end of a function");
            break;
        }
        int at = frame->ip;
        vm->err_line = (frame->fn->lines != NULL) ? frame->fn->lines[at] : 0;
        vm->err_fn = frame->fn->name;
        uint8_t op = frame->fn->code[frame->ip++];
        switch (op) {
        case OP_NIL: {
            Value nil;
            memset(&nil, 0, sizeof(nil));
            if (!push(vm, nil)) {
                goto vm_end;
            }
            break;
        }
        case OP_TRUE:
            if (!push(vm, make_bool(1))) goto vm_end;
            break;
        case OP_FALSE:
            if (!push(vm, make_bool(0))) goto vm_end;
            break;
        case OP_CONST: {
            if (!read_operand(vm, frame, 2)) goto vm_end;
            int index = read_u16(frame);
            if (index < 0 || index >= program->nconst) {
                vm_fail(vm, "invalid constant");
                goto vm_end;
            }
            if (!push(vm, program->consts[index])) goto vm_end;
            break;
        }
        case OP_LOAD: {
            if (!read_operand(vm, frame, 2)) goto vm_end;
            int slot = read_u16(frame);
            if (slot < 0 || slot >= frame->fn->nlocals || frame->slots == NULL) {
                vm_fail(vm, "invalid local slot");
                goto vm_end;
            }
            if (!push(vm, frame->slots[slot])) goto vm_end;
            break;
        }
        case OP_STORE: {
            if (!read_operand(vm, frame, 2)) goto vm_end;
            int slot = read_u16(frame);
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (slot < 0 || slot >= frame->fn->nlocals || frame->slots == NULL) {
                vm_fail(vm, "invalid local slot");
                goto vm_end;
            }
            frame->slots[slot] = value;
            break;
        }
        case OP_POP: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            break;
        }
        case OP_DUP: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (!push(vm, value) || !push(vm, value)) goto vm_end;
            break;
        }
        case OP_ADD_I:
        case OP_SUB_I:
        case OP_MUL_I:
        case OP_DIV_I:
        case OP_MOD_I: {
            Value right, left;
            if (!pop(vm, &right) || !pop(vm, &left)) goto vm_end;
            if (left.kind != VAL_INT || right.kind != VAL_INT) {
                vm_fail(vm, "expected integers");
                goto vm_end;
            }
            int64_t result = 0;
            if (op == OP_ADD_I) {
                result = (int64_t)((uint64_t)left.i + (uint64_t)right.i);
            } else if (op == OP_SUB_I) {
                result = (int64_t)((uint64_t)left.i - (uint64_t)right.i);
            } else if (op == OP_MUL_I) {
                result = (int64_t)((uint64_t)left.i * (uint64_t)right.i);
            } else {
                if (right.i == 0) {
                    vm_fail(vm, op == OP_DIV_I ? "division by zero" : "modulo by zero");
                    goto vm_end;
                }
                if (div_overflow(left.i, right.i)) {
                    vm_fail(vm, "integer overflow");
                    goto vm_end;
                }
                result = (op == OP_DIV_I) ? (left.i / right.i) : (left.i % right.i);
            }
            if (!push(vm, make_int(result))) goto vm_end;
            break;
        }
        case OP_NEG_I: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (value.kind != VAL_INT) {
                vm_fail(vm, "expected an integer");
                goto vm_end;
            }
            if (value.i == INT64_MIN) {
                vm_fail(vm, "integer overflow");
                goto vm_end;
            }
            if (!push(vm, make_int(-value.i))) goto vm_end;
            break;
        }
        case OP_ADD_F:
        case OP_SUB_F:
        case OP_MUL_F:
        case OP_DIV_F: {
            Value right, left;
            if (!pop(vm, &right) || !pop(vm, &left)) goto vm_end;
            if (left.kind != VAL_FLOAT || right.kind != VAL_FLOAT) {
                vm_fail(vm, "expected floats");
                goto vm_end;
            }
            double result = 0;
            if (op == OP_ADD_F) result = left.f + right.f;
            else if (op == OP_SUB_F) result = left.f - right.f;
            else if (op == OP_MUL_F) result = left.f * right.f;
            else {
                if (right.f == 0.0) {
                    vm_fail(vm, "division by zero");
                    goto vm_end;
                }
                result = left.f / right.f;
            }
            if (!push(vm, make_float(result))) goto vm_end;
            break;
        }
        case OP_NEG_F: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (value.kind != VAL_FLOAT) {
                vm_fail(vm, "expected a float");
                goto vm_end;
            }
            if (!push(vm, make_float(-value.f))) goto vm_end;
            break;
        }
        case OP_I2F: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (value.kind != VAL_INT) {
                vm_fail(vm, "expected an integer");
                goto vm_end;
            }
            if (!push(vm, make_float((double)value.i))) goto vm_end;
            break;
        }
        case OP_EQ_I:
        case OP_NE_I:
        case OP_LT_I:
        case OP_GT_I:
        case OP_LE_I:
        case OP_GE_I:
        case OP_EQ_F:
        case OP_NE_F:
        case OP_LT_F:
        case OP_GT_F:
        case OP_LE_F:
        case OP_GE_F:
        case OP_EQ_B:
        case OP_NE_B:
        case OP_EQ_S:
        case OP_NE_S: {
            Value right, left;
            if (!pop(vm, &right) || !pop(vm, &left)) goto vm_end;
            int cmp = 0;
            if (op == OP_EQ_S || op == OP_NE_S) {
                cmp = values_equal(left, right);
                if (op == OP_NE_S) cmp = !cmp;
            } else if (op == OP_EQ_B || op == OP_NE_B) {
                if (left.kind != VAL_BOOL || right.kind != VAL_BOOL) {
                    vm_fail(vm, "expected bools");
                    goto vm_end;
                }
                cmp = left.b == right.b;
                if (op == OP_NE_B) cmp = !cmp;
            } else if (op >= OP_EQ_F && op <= OP_GE_F) {
                if (left.kind != VAL_FLOAT || right.kind != VAL_FLOAT) {
                    vm_fail(vm, "expected floats");
                    goto vm_end;
                }
                if (op == OP_EQ_F) cmp = left.f == right.f;
                else if (op == OP_NE_F) cmp = left.f != right.f;
                else if (op == OP_LT_F) cmp = left.f < right.f;
                else if (op == OP_GT_F) cmp = left.f > right.f;
                else if (op == OP_LE_F) cmp = left.f <= right.f;
                else cmp = left.f >= right.f;
            } else {
                if (left.kind != VAL_INT || right.kind != VAL_INT) {
                    vm_fail(vm, "expected integers");
                    goto vm_end;
                }
                if (op == OP_EQ_I) cmp = left.i == right.i;
                else if (op == OP_NE_I) cmp = left.i != right.i;
                else if (op == OP_LT_I) cmp = left.i < right.i;
                else if (op == OP_GT_I) cmp = left.i > right.i;
                else if (op == OP_LE_I) cmp = left.i <= right.i;
                else cmp = left.i >= right.i;
            }
            if (!push(vm, make_bool(cmp))) goto vm_end;
            break;
        }
        case OP_NOT: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (value.kind != VAL_BOOL) {
                vm_fail(vm, "expected a bool");
                goto vm_end;
            }
            if (!push(vm, make_bool(!value.b))) goto vm_end;
            break;
        }
        case OP_CONCAT: {
            Value right, left;
            if (!pop(vm, &right) || !pop(vm, &left)) goto vm_end;
            if (left.kind != VAL_STR || right.kind != VAL_STR) {
                vm_fail(vm, "expected strings");
                goto vm_end;
            }
            if (left.slen < 0 || right.slen < 0 || left.slen > INT_MAX - right.slen) {
                vm_fail(vm, "string is too long");
                goto vm_end;
            }
            int len = left.slen + right.slen;
            char *text = vm_copy(vm, "", 0);
            if (len > 0) {
                text = (char *)arena_alloc(&vm->arena, (size_t)len + 1);
                if (left.slen > 0) {
                    memcpy(text, left.s, (size_t)left.slen);
                }
                if (right.slen > 0) {
                    memcpy(text + left.slen, right.s, (size_t)right.slen);
                }
                text[len] = '\0';
            }
            Value out;
            memset(&out, 0, sizeof(out));
            out.kind = VAL_STR;
            out.s = text;
            out.slen = len;
            if (!push(vm, out)) goto vm_end;
            break;
        }
        case OP_JUMP:
        case OP_JUMP_IF_FALSE:
        case OP_JUMP_IF_TRUE: {
            Value cond;
            int conditional = op != OP_JUMP;
            if (conditional && !pop(vm, &cond)) goto vm_end;
            if (!read_operand(vm, frame, 4)) goto vm_end;
            int32_t rel = read_i32(frame);
            if (conditional && cond.kind != VAL_BOOL) {
                vm_fail(vm, "expected a bool");
                goto vm_end;
            }
            if (!conditional || (op == OP_JUMP_IF_FALSE && !cond.b) || (op == OP_JUMP_IF_TRUE && cond.b)) {
                frame->ip += rel;
            }
            break;
        }
        case OP_CALL: {
            if (!read_operand(vm, frame, 3)) goto vm_end;
            int index = read_u16(frame);
            int argc = frame->fn->code[frame->ip++];
            if (index < 0 || index >= program->nfn) {
                vm_fail(vm, "invalid function");
                goto vm_end;
            }
            CompiledFn *callee = &program->fns[index];
            if (argc != callee->nparams) {
                vm_fail(vm, "wrong number of arguments");
                goto vm_end;
            }
            if (vm->frame_count >= FRAME_MAX) {
                vm_fail(vm, "call stack overflow");
                goto vm_end;
            }
            Value args[64];
            if (argc > 64) {
                vm_fail(vm, "too many arguments");
                goto vm_end;
            }
            for (int i = argc - 1; i >= 0; i--) {
                if (!pop(vm, &args[i])) goto vm_end;
            }
            Value *slots = NULL;
            if (callee->nlocals > 0) {
                slots = (Value *)calloc((size_t)callee->nlocals, sizeof(Value));
                if (slots == NULL) {
                    vm_fail(vm, "out of memory");
                    goto vm_end;
                }
            }
            for (int i = 0; i < argc; i++) {
                slots[i] = args[i];
            }
            Frame *next = &vm->frames[vm->frame_count++];
            next->fn = callee;
            next->ip = 0;
            next->slots = slots;
            break;
        }
        case OP_PRINT:
        case OP_PRINTLN: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            print_value(stdout, value);
            if (op == OP_PRINTLN) {
                fputc('\n', stdout);
            }
            fflush(stdout);
            Value nil;
            memset(&nil, 0, sizeof(nil));
            if (!push(vm, nil)) goto vm_end;
            break;
        }
        case OP_LEN: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            if (value.kind != VAL_STR) {
                vm_fail(vm, "len() expects a string");
                goto vm_end;
            }
            if (!push(vm, make_int(value.slen))) goto vm_end;
            break;
        }
        case OP_STR: {
            Value value;
            if (!pop(vm, &value)) goto vm_end;
            char buf[128];
            const char *text = buf;
            int len = 0;
            if (value.kind == VAL_INT) {
                len = snprintf(buf, sizeof(buf), "%" PRId64, value.i);
            } else if (value.kind == VAL_FLOAT) {
                len = snprintf(buf, sizeof(buf), "%.15g", value.f);
            } else if (value.kind == VAL_BOOL) {
                text = value.b ? "true" : "false";
                len = value.b ? 4 : 5;
            } else if (value.kind == VAL_STR) {
                text = value.s != NULL ? value.s : "";
                len = value.slen;
            } else {
                vm_fail(vm, "str() cannot convert this value");
                goto vm_end;
            }
            if (len < 0) {
                vm_fail(vm, "str() failed");
                goto vm_end;
            }
            Value out;
            memset(&out, 0, sizeof(out));
            out.kind = VAL_STR;
            out.s = vm_copy(vm, text, len);
            out.slen = len;
            if (!push(vm, out)) goto vm_end;
            break;
        }
        case OP_RETURN: {
            Value result;
            if (!pop(vm, &result)) goto vm_end;
            free(frame->slots);
            frame->slots = NULL;
            vm->frame_count--;
            if (vm->frame_count == 0) {
                vm->result = result;
                vm->halted = 1;
                goto vm_end;
            }
            if (!push(vm, result)) goto vm_end;
            break;
        }
        default:
            vm_fail(vm, "unknown instruction");
            goto vm_end;
        }
    }

vm_end:
    if (vm->failed) {
        fflush(stdout);
        const char *where = vm->file != NULL ? vm->file : "<input>";
        const char *fn = vm->err_fn != NULL ? vm->err_fn : "main";
        if (vm->err_line > 0) {
            fprintf(stderr, "runtime error: %s:%d in %s: %s\n", where, vm->err_line, fn, vm->err);
        } else {
            fprintf(stderr, "runtime error: %s in %s: %s\n", where, fn, vm->err);
        }
    }
    for (int i = 0; i < vm->frame_count; i++) {
        free(vm->frames[i].slots);
    }
    arena_free(&vm->arena);
    int code = 1;
    if (!vm->failed) {
        if (vm->result.kind == VAL_INT) {
            if (vm->result.i > INT_MAX) {
                code = INT_MAX;
            } else if (vm->result.i < INT_MIN) {
                code = INT_MIN;
            } else {
                code = (int)vm->result.i;
            }
        } else {
            code = 0;
        }
    }
    free(vm);
    return code;
}
