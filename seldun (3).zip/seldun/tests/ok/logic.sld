fn side() -> bool {
    println("side")
    return true
}

fn main() -> int {
    if false && side() {
        println("taken")
    } else {
        println("skip-and")
    }
    if true || side() {
        println("skip-or")
    } else {
        println("or-else")
    }
    if true && side() {
        println("and-taken")
    }
    return 0
}
