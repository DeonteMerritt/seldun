fn main() -> int {
    let x = 1
    {
        let x = 2
        println(x)
    }
    println(x)
    let i = 5
    var n = 0
    for i in 0..i {
        n = n + 1
    }
    println(n)
    println(i)
    return 0
}
