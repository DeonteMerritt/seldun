fn main() -> int {
    if "ab" == "ab" && "a" != "b" && len("Seldun") == 6 && "a" + "b" == "ab" {
        println("yes")
    } else {
        println("no")
    }
    println(str(42) + "!")
    println("" + "a")
    return 0
}
