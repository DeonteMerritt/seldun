fn main() -> int {
    println("a\nb")
    return 0
}
