fn main() -> int {
    println("a"); println("b")
    let n = 1 +
        2
    println(n)
    return 0
}
