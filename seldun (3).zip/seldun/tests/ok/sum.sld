fn main() -> int {
    var i = 1
    var sum = 0
    while i <= 10 {
        sum = sum + i
        i = i + 1
    }
    println(sum)
    return 0
}
