fn main() -> int {
    for i in -2..1 {
        println(i)
    }
    return 0
}
