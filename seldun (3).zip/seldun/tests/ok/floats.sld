fn main() -> int {
    let x = 1.5
    let y: float = 2
    println(x + y)
    println(7.0 / 2.0)
    println(1 + 2.5)
    println(-1.25)
    return 0
}
