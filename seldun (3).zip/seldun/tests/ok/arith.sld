fn main() -> int {
    println(-3 + 10)
    println(10 % 3)
    println(20 - 4 * 3)
    if !false {
        println("not")
    }
    return 0
}
