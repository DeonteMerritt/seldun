fn bump() -> int {
    println("once")
    return 1
}

fn main() -> int {
    println(bump() + 2.0)
    return 0
}
