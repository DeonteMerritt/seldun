#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
BIN="$ROOT/build/seldun"
CC=${CC:-gcc}

mkdir -p "$ROOT/build"
"$CC" -std=c11 -Wall -Wextra -Werror -pedantic -O2 -o "$BIN" "$ROOT"/src/*.c

fail() {
    echo "FAIL $1" >&2
    exit 1
}

run_ok() {
    src=$1
    expected=$2
    out=$(mktemp)
    err=$(mktemp)
    if ! "$BIN" run "$src" >"$out" 2>"$err"; then
        echo "---- stdout ----" >&2
        cat "$out" >&2
        echo "---- stderr ----" >&2
        cat "$err" >&2
        fail "$src (exit)"
    fi
    if ! diff -u "$expected" "$out"; then
        fail "$src (output)"
    fi
    if [ -s "$err" ]; then
        cat "$err" >&2
        fail "$src (stderr)"
    fi
    rm -f "$out" "$err"
    echo "ok $src"
}

run_fail() {
    src=$1
    out=$(mktemp)
    err=$(mktemp)
    if "$BIN" check "$src" >"$out" 2>"$err"; then
        fail "$src (expected compile error)"
    fi
    if ! grep -q "error:" "$err"; then
        cat "$err" >&2
        fail "$src (missing diagnostic)"
    fi
    if [ -s "$out" ]; then
        cat "$out" >&2
        fail "$src (unexpected stdout)"
    fi
    rm -f "$out" "$err"
    echo "ok $src"
}

for src in "$ROOT"/examples/*.sld; do
    base=$(basename "$src" .sld)
    run_ok "$src" "$ROOT/tests/expected/$base.out"
done

for src in "$ROOT"/tests/ok/*.sld; do
    run_ok "$src" "${src%.sld}.out"
done

for src in "$ROOT"/tests/fail/*.sld; do
    run_fail "$src"
done

out=$(mktemp)
err=$(mktemp)
if "$BIN" run "$ROOT/tests/runtime/divzero.sld" >"$out" 2>"$err"; then
    fail "divzero (expected runtime error)"
fi
if ! grep -q "division by zero" "$err"; then
    cat "$err" >&2
    fail "divzero (message)"
fi
rm -f "$out" "$err"
echo "ok divzero"

out=$(mktemp)
err=$(mktemp)
if ! "$BIN" check "$ROOT/examples/hello.sld" >"$out" 2>"$err"; then
    fail "check hello"
fi
if [ -s "$out" ] || [ -s "$err" ]; then
    fail "check hello produced output"
fi
rm -f "$out" "$err"
echo "ok check"

tmp=$(mktemp)
printf '\357\273\277fn main() {\r\n    println("bom")\r\n}\r\n' >"$tmp"
out=$(mktemp)
got=$("$BIN" run "$tmp")
printf '%s\n' "bom" >"$out"
if [ "$got" != "bom" ]; then
    printf 'got [%s]\n' "$got" >&2
    fail "bom/crlf"
fi
rm -f "$tmp" "$out"
echo "ok bom/crlf"

dump=$("$BIN" dump "$ROOT/examples/hello.sld")
printf '%s\n' "$dump" | grep -q "PRINTLN" || fail "dump"
echo "ok dump"

echo "all tests passed"
