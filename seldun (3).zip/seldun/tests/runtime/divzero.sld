fn main() -> int {
    println(1 / 0)
    return 0
}
