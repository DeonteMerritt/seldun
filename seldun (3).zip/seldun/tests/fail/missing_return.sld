fn f() -> int {
    println("x")
}

fn main() -> int {
    return f()
}
