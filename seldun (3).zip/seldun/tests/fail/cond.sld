fn main() {
    if 1 {
        println("no")
    }
}
