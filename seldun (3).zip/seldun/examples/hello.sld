// Sample Seldun program.
fn greet(name: string) -> string {
    return "Hello from " + name
}

fn main() -> int {
    println(greet("Seldun"))
    return 0
}
