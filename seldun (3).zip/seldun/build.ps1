# Build seldun.exe into .\build\seldun.exe
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$OutDir = Join-Path $Root "build"
if (-not (Test-Path -LiteralPath $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir | Out-Null
}

$Sources = @(Get-ChildItem -LiteralPath (Join-Path $Root "src") -Filter "*.c" | ForEach-Object { $_.FullName })
if ($Sources.Count -eq 0) {
    Write-Error "No C sources found in src\"
}

$Output = Join-Path $OutDir "seldun.exe"

function Test-ToolOnPath([string]$Name) {
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

if (Test-ToolOnPath "cl") {
    $ObjDir = Join-Path $OutDir "obj"
    if (-not (Test-Path -LiteralPath $ObjDir)) {
        New-Item -ItemType Directory -Path $ObjDir | Out-Null
    }
    $Fo = "/Fo" + $ObjDir + "\"
    $Fe = "/Fe" + $Output
    & cl.exe /nologo /W3 /O2 /std:c11 /D_CRT_SECURE_NO_WARNINGS $Fo $Fe @Sources
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} elseif (Test-ToolOnPath "gcc") {
    & gcc -std=c11 -O2 -Wall -Wextra -o $Output @Sources
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} elseif (Test-ToolOnPath "clang") {
    & clang -std=c11 -O2 -Wall -Wextra -o $Output @Sources
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} else {
    Write-Error "No C compiler was found on PATH. Install MinGW-w64 (gcc) or run this from a Visual Studio Developer PowerShell so cl is available."
    exit 1
}

Write-Host "Built $Output"
