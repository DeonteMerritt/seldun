# Seldun

Seldun is a small compiled language. Source files use the `.sld` extension. The compiler reads a program, typechecks it, compiles it to bytecode, and runs that bytecode. The Windows compiler is `seldun.exe`.

No VS Code extension is required. Open this folder in VS Code and use the integrated PowerShell terminal.

## Run from VS Code PowerShell

Open the project folder, then open the terminal (`Terminal: Create New Terminal`) and choose PowerShell. The current directory should be the project root.

The prebuilt 64-bit Windows compiler is:

`dist\seldun.exe`

Run the sample program:

```powershell
.\dist\seldun.exe .\examples\hello.sld
```

Expected output:

```text
Hello from Seldun
```

Other samples:

```powershell
.\dist\seldun.exe .\examples\fib.sld
.\dist\seldun.exe .\examples\fizzbuzz.sld
.\dist\seldun.exe check .\examples\hello.sld
```

`fib.sld` prints `55`. `fizzbuzz.sld` prints the numbers 1 through 15 with Fizz, Buzz, and FizzBuzz.

## Build `seldun.exe` on Windows

From the same PowerShell terminal:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
.\build\seldun.exe .\examples\hello.sld
```

`build.ps1` writes the compiler to:

`build\seldun.exe`

It uses the first compiler it finds on `PATH`:

1. `cl` from a Visual Studio Developer PowerShell
2. `gcc` from MinGW-w64
3. `clang`

`build.cmd` runs the same script if execution policy blocks `.\build.ps1`.

CMake is also available if you prefer it:

```powershell
cmake -S . -B build-cmake
cmake --build build-cmake --config Release
```

A Visual Studio CMake build does not use the `build\seldun.exe` path above. Use `build.ps1` when you want that file.

## Build on Linux or macOS

```sh
make
./build/seldun examples/hello.sld
make test
```

A Windows exe can be cross-compiled when `x86_64-w64-mingw32-gcc` is installed:

```sh
make win
```

That writes `dist/seldun.exe`.

## Language

A program is a list of functions. Execution starts at `main`. `main` takes no parameters and returns `int` or nothing.

```sld
fn greet(name: string) -> string {
    return "Hello from " + name
}

fn main() -> int {
    println(greet("Seldun"))
    return 0
}
```

Types are `int`, `float`, `bool`, `string`, and `void` (return type only). `let` is immutable. `var` can be assigned. Types can be written or inferred from the initializer:

```sld
let name: string = "Seldun"
var count = 0
count = count + 1
```

`int` values used where a `float` is expected are promoted. Strings join with `+`. `&&` and `||` stop early. A newline or a semicolon ends a statement. Comments are `// line` and `/* block */`.

```sld
if n <= 1 {
    return n
} else {
    return n * fact(n - 1)
}

while i <= 10 {
    sum = sum + i
    i = i + 1
}

for i in 1..16 {
    println(i)
}
```

`for i in a..b` counts from `a` up to but not including `b`. `i` is an `int` that belongs to the loop. `a` and `b` are evaluated once.

Built-in functions:

| Call | Result |
| --- | --- |
| `print(value)` | Writes `value` with no newline |
| `println(value)` | Writes `value` and a newline |
| `len(text)` | Number of bytes in a string |
| `str(value)` | `int`, `float`, `bool`, or `string` converted to a string |

An `int` returned from `main` becomes the process exit code. A `main` with no return type exits 0.
